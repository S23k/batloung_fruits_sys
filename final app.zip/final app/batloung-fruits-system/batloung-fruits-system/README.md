# Batloung Fruits Distribution Management System
DIWA2110 Full-Stack Development assignment starter.

## Technology
- React + Vite frontend
- Node.js + Express REST API
- MySQL database
- JWT login with Administrator and Sales roles

## Requirements
Install Node.js LTS and MySQL Server. Use a terminal (Command Prompt or PowerShell).

## 1. Create the database
1. Open MySQL Workbench or the MySQL command-line client.
2. Run the complete script in `database/schema.sql`.
3. The script creates `batloung_fruits` and sample data.

*Alternatively, run the automated setup script from the `backend` folder:*
```bash
node setupDb.js YOUR_MYSQL_PASSWORD
```
This automatically updates `backend/.env`, creates the database, and loads the schema.

The default database settings are in `backend/.env.example`. Copy it to `backend/.env` and change the MySQL password to your own.

## 2. Start the backend
Open a terminal in the `backend` folder and run:

```bash
npm install
```

Copy `.env.example` to `.env`, then edit the values. Start the API:

```bash
npm run dev
```

The API should run at http://localhost:5000. Test http://localhost:5000/api/health.

## 3. Start the frontend
Open a SECOND terminal in the `frontend` folder:

```bash
npm install
npm run dev
```

Open the local address Vite prints (usually http://localhost:5173).

**Important for Windows:** Do not type `vite` by itself. Run `npm install` first inside the folder that contains `package.json`, then run `npm run dev`.

## Demo accounts
The seed accounts use these passwords (change them before real use):
- Administrator: `admin@batloung.co.za` / `Admin123!`
- Sales: `sales@batloung.co.za` / `Sales123!`

The seed SQL stores bcrypt hashes for these demo passwords.

## Features in this starter
- Dashboard totals and order summaries
- Fruit CRUD, including the five specified fruit types
- Supplier CRUD and filtering by South African province
- Street vendor CRUD with geographic location mapping
- Interactive Live Satellite Map & GPS location system (Esri World Imagery + street networks & labels, realistic GIS streets, and OSM)
- Multi-modal travel time estimation to destination: by car (35 km/h), bicycle (15 km/h), or on foot (4.8 km/h)
- Automated "Nearest Vendor to HQ" spotlight detection, route polyline preview, and quick focus
- Automatic destination name resolution (reverse geocoding) upon "Ping My Location" or map click
- One-click "Ping My Location" via browser Geolocation API with live destination identification
- Click-to-pin location tool on interactive satellite map with expanded Maseru area presets
- Real-time distance calculation (Haversine formula in km) from Batloung Fruits Central Depot (HQ)
- Distance rings (2 km and 5 km) and route polylines showing vendor distribution radius
- Products defined by fruit + box size + selling price
- Incoming stock entries linked to suppliers and products
- Order creation, line items, order status updates, and stock deduction on completion
- Cancelled orders do not deduct stock
- Search/filter controls for the main lists
- Sales-by-fruit, sales-by-box-size, sales-by-vendor, province purchases, pending/completed order reports
- JWT login and role-aware UI/API middleware
- MySQL schema, relationships, ERD description, and assignment documentation

## Important implementation notes
- This is an educational starter; test it and understand each file before presenting.
- The API rejects an order quantity greater than current stock.
- Stock is deducted only when an order transitions to `Completed`; the transaction prevents partial stock updates.
- If an order is moved away from Completed, stock is not automatically restored. For a production system, use a controlled return/reversal workflow.
- Configure strong secrets and database credentials before deployment.
