import bcrypt from 'bcryptjs';
import pool from './db.js';

try {
  const admin = await bcrypt.hash('Admin123!', 10);
  const sales = await bcrypt.hash('Sales123!', 10);
  await pool.execute(
    `INSERT INTO users (name,email,password_hash,role) VALUES
     ('System Administrator','admin@batloung.co.za',?,'Administrator'),
     ('Sales User','sales@batloung.co.za',?,'Sales')
     ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash)`,
    [admin, sales]
  );
  console.log('Demo users seeded. Admin123! and Sales123!');
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
} finally {
  await pool.end();
}
