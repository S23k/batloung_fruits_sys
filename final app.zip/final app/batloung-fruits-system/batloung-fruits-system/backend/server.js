import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import pool from './db.js';
import { authenticate, allowRoles } from './middleware/auth.js';

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 5000);
const ADMIN = ['Administrator'];
const BOTH = ['Administrator', 'Sales'];
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 100 }));
app.get('/api/health', (req,res) => res.json({ status: 'ok', service: 'Batloung Fruits API' }));

export const BATLOUNG_DEPOT = {
  name: 'Batloung Fruits Central Depot',
  address: 'Kingsway Road, Maseru Central, Maseru, Lesotho',
  latitude: -29.31360,
  longitude: 27.48440
};

export function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return null;
  const nLat1 = Number(lat1), nLon1 = Number(lon1);
  const nLat2 = Number(lat2), nLon2 = Number(lon2);
  if (isNaN(nLat1) || isNaN(nLon1) || isNaN(nLat2) || isNaN(nLon2)) return null;
  const R = 6371; // Earth's radius in kilometers
  const toRad = deg => (deg * Math.PI) / 180;
  const dLat = toRad(nLat2 - nLat1);
  const dLon = toRad(nLon2 - nLon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(nLat1)) * Math.cos(toRad(nLat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}

app.get('/api/system/location', (req, res) => {
  res.json({ depot: BATLOUNG_DEPOT });
});

app.post('/api/auth/login', async (req,res,next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password are required.' });
    const [rows] = await pool.execute('SELECT id,name,email,password_hash,role FROM users WHERE email=?', [email]);
    if (!rows.length || !(await bcrypt.compare(password, rows[0].password_hash))) {
      return res.status(401).json({ message: 'Incorrect email or password.' });
    }
    const user = rows[0];
    const token = jwt.sign({ id:user.id, name:user.name, email:user.email, role:user.role },
      process.env.JWT_SECRET || 'development_only_change_me', { expiresIn:'8h' });
    res.json({ token, user:{ id:user.id, name:user.name, email:user.email, role:user.role } });
  } catch (e) { next(e); }
});
app.use('/api', authenticate);

const wrap = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const rows = async (sql, params=[]) => (await pool.execute(sql, params))[0];
const clean = value => String(value ?? '').trim();
const positiveInt = value => Number.isInteger(Number(value)) && Number(value) > 0;

app.get('/api/fruits', wrap(async (req,res) => res.json(await rows('SELECT * FROM fruits ORDER BY name'))));
app.get('/api/fruits/:id', wrap(async (req,res) => {
  const data = await rows('SELECT * FROM fruits WHERE id=?',[req.params.id]);
  if (!data.length) return res.status(404).json({message:'Fruit not found.'}); res.json(data[0]);
}));
app.post('/api/fruits', allowRoles(...ADMIN), wrap(async (req,res) => {
  const name=clean(req.body.name);
  if (!['Apples','Bananas','Oranges','Mangoes','Grapes'].includes(name)) return res.status(400).json({message:'Choose one of the five specified fruits.'});
  const result=await rows('INSERT INTO fruits(name,description,active) VALUES(?,?,?)',[name,clean(req.body.description),req.body.active===false?0:1]);
  res.status(201).json({id:result.insertId,message:'Fruit created.'});
}));
app.put('/api/fruits/:id', allowRoles(...ADMIN), wrap(async (req,res) => {
  const name=clean(req.body.name);
  if (!['Apples','Bananas','Oranges','Mangoes','Grapes'].includes(name)) return res.status(400).json({message:'Choose one of the five specified fruits.'});
  const result=await rows('UPDATE fruits SET name=?,description=?,active=? WHERE id=?',[name,clean(req.body.description),req.body.active===false?0:1,req.params.id]);
  if (!result.affectedRows) return res.status(404).json({message:'Fruit not found.'}); res.json({message:'Fruit updated.'});
}));
app.delete('/api/fruits/:id', allowRoles(...ADMIN), wrap(async (req,res) => {
  try { const result=await rows('DELETE FROM fruits WHERE id=?',[req.params.id]); if(!result.affectedRows)return res.status(404).json({message:'Fruit not found.'}); res.json({message:'Fruit deleted.'}); }
  catch { res.status(409).json({message:'This fruit is referenced by products and cannot be deleted. Deactivate it instead.'}); }
}));

app.get('/api/box-sizes', wrap(async(req,res)=>res.json(await rows('SELECT * FROM box_sizes ORDER BY id'))));
app.get('/api/products', wrap(async(req,res)=>res.json(await rows(`SELECT p.id,p.fruit_id,p.box_size_id,p.selling_price,p.active,f.name fruit_name,b.name box_size,
 (SELECT COALESCE(SUM(se.quantity),0) FROM stock_entries se WHERE se.product_id=p.id) -
 (SELECT COALESCE(SUM(oi.quantity),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=p.id AND o.status='Completed') stock
 FROM products p JOIN fruits f ON f.id=p.fruit_id JOIN box_sizes b ON b.id=p.box_size_id ORDER BY f.name,b.id`))));
app.post('/api/products', allowRoles(...ADMIN), wrap(async(req,res)=>{
  const {fruit_id,box_size_id,selling_price}=req.body;
  if(!positiveInt(fruit_id)||!positiveInt(box_size_id)||!Number.isFinite(Number(selling_price))||Number(selling_price)<0) return res.status(400).json({message:'Fruit, box size and a non-negative selling price are required.'});
  const result=await rows('INSERT INTO products(fruit_id,box_size_id,selling_price) VALUES(?,?,?)',[fruit_id,box_size_id,selling_price]);
  res.status(201).json({id:result.insertId,message:'Product created.'});
}));
app.put('/api/products/:id', allowRoles(...ADMIN), wrap(async(req,res)=>{
  const {fruit_id,box_size_id,selling_price,active}=req.body;
  if(!positiveInt(fruit_id)||!positiveInt(box_size_id)||!Number.isFinite(Number(selling_price))||Number(selling_price)<0)return res.status(400).json({message:'Valid fruit, box size and price are required.'});
  const result=await rows('UPDATE products SET fruit_id=?,box_size_id=?,selling_price=?,active=? WHERE id=?',[fruit_id,box_size_id,selling_price,active===false?0:1,req.params.id]);
  if(!result.affectedRows)return res.status(404).json({message:'Product not found.'});res.json({message:'Product updated.'});
}));

app.get('/api/suppliers', wrap(async(req,res)=>{
 const q=`%${clean(req.query.search)}%`; const province=clean(req.query.province);
 res.json(await rows(`SELECT * FROM suppliers WHERE (name LIKE ? OR contact_person LIKE ? OR telephone LIKE ?) AND (?='' OR province=?) ORDER BY name`,[q,q,q,province,province]));
}));
app.post('/api/suppliers', allowRoles(...ADMIN), wrap(async(req,res)=>{
 const {name,province,contact_person,telephone,email,physical_address}=req.body;
 const provinces=['Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','Northern Cape','North West','Western Cape'];
 if(![name,province,contact_person,telephone,physical_address].every(v=>clean(v))||!provinces.includes(province))return res.status(400).json({message:'Complete all required fields and choose a valid South African province.'});
 const r=await rows('INSERT INTO suppliers(name,province,contact_person,telephone,email,physical_address) VALUES(?,?,?,?,?,?)',[clean(name),province,clean(contact_person),clean(telephone),clean(email),clean(physical_address)]);
 res.status(201).json({id:r.insertId,message:'Supplier created.'});
}));
app.put('/api/suppliers/:id', allowRoles(...ADMIN), wrap(async(req,res)=>{
 const {name,province,contact_person,telephone,email,physical_address}=req.body;
 const provinces=['Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','Northern Cape','North West','Western Cape'];
 if(![name,province,contact_person,telephone,physical_address].every(v=>clean(v))||!provinces.includes(province))return res.status(400).json({message:'Complete all required fields and choose a valid province.'});
 const r=await rows('UPDATE suppliers SET name=?,province=?,contact_person=?,telephone=?,email=?,physical_address=? WHERE id=?',[clean(name),province,clean(contact_person),clean(telephone),clean(email),clean(physical_address),req.params.id]);
 if(!r.affectedRows)return res.status(404).json({message:'Supplier not found.'});res.json({message:'Supplier updated.'});
}));
app.delete('/api/suppliers/:id', allowRoles(...ADMIN), wrap(async(req,res)=>{
 try{const r=await rows('DELETE FROM suppliers WHERE id=?',[req.params.id]);if(!r.affectedRows)return res.status(404).json({message:'Supplier not found.'});res.json({message:'Supplier deleted.'});}
 catch{res.status(409).json({message:'Supplier has stock history and cannot be deleted.'});}
}));

app.get('/api/vendors', wrap(async(req,res)=>{
 const q=`%${clean(req.query.search)}%`;
 const vendorList = await rows(`SELECT * FROM street_vendors WHERE vendor_name LIKE ? OR business_name LIKE ? OR location_area LIKE ? ORDER BY vendor_name`,[q,q,q]);
 const enriched = vendorList.map(v => ({
   ...v,
   distance_km: calculateDistanceKm(BATLOUNG_DEPOT.latitude, BATLOUNG_DEPOT.longitude, v.latitude, v.longitude),
   depot_name: BATLOUNG_DEPOT.name
 }));
 res.json(enriched);
}));
app.post('/api/vendors', allowRoles(...BOTH), wrap(async(req,res)=>{
 const {vendor_name,business_name,telephone,location_area,registration_date,status,latitude,longitude}=req.body;
 if(![vendor_name,business_name,telephone,location_area,registration_date].every(v=>clean(v)))return res.status(400).json({message:'Complete all required vendor fields.'});
 const lat = latitude !== undefined && latitude !== '' && !isNaN(Number(latitude)) ? Number(latitude) : null;
 const lng = longitude !== undefined && longitude !== '' && !isNaN(Number(longitude)) ? Number(longitude) : null;
 const r=await rows('INSERT INTO street_vendors(vendor_name,business_name,telephone,location_area,latitude,longitude,registration_date,status) VALUES(?,?,?,?,?,?,?,?)',[clean(vendor_name),clean(business_name),clean(telephone),clean(location_area),lat,lng,registration_date,status==='Inactive'?'Inactive':'Active']);
 res.status(201).json({id:r.insertId,message:'Vendor registered.'});
}));
app.put('/api/vendors/:id', allowRoles(...BOTH), wrap(async(req,res)=>{
 const {vendor_name,business_name,telephone,location_area,registration_date,status,latitude,longitude}=req.body;
 if(![vendor_name,business_name,telephone,location_area,registration_date].every(v=>clean(v)))return res.status(400).json({message:'Complete all required vendor fields.'});
 const lat = latitude !== undefined && latitude !== '' && !isNaN(Number(latitude)) ? Number(latitude) : null;
 const lng = longitude !== undefined && longitude !== '' && !isNaN(Number(longitude)) ? Number(longitude) : null;
 const r=await rows('UPDATE street_vendors SET vendor_name=?,business_name=?,telephone=?,location_area=?,latitude=?,longitude=?,registration_date=?,status=? WHERE id=?',[clean(vendor_name),clean(business_name),clean(telephone),clean(location_area),lat,lng,registration_date,status==='Inactive'?'Inactive':'Active',req.params.id]);
 if(!r.affectedRows)return res.status(404).json({message:'Vendor not found.'});res.json({message:'Vendor updated.'});
}));
app.delete('/api/vendors/:id', allowRoles(...ADMIN), wrap(async(req,res)=>{
 try{const r=await rows('DELETE FROM street_vendors WHERE id=?',[req.params.id]);if(!r.affectedRows)return res.status(404).json({message:'Vendor not found.'});res.json({message:'Vendor deleted.'});}
 catch{res.status(409).json({message:'Vendor has order history and cannot be deleted.'});}
}));

app.get('/api/stock', wrap(async(req,res)=>res.json(await rows(`SELECT se.*,s.name supplier_name,f.name fruit_name,b.name box_size FROM stock_entries se JOIN suppliers s ON s.id=se.supplier_id JOIN products p ON p.id=se.product_id JOIN fruits f ON f.id=p.fruit_id JOIN box_sizes b ON b.id=p.box_size_id ORDER BY se.received_date DESC,se.id DESC`))));
app.post('/api/stock', allowRoles(...ADMIN), wrap(async(req,res)=>{
 const {supplier_id,product_id,quantity,purchase_unit_cost,received_date,notes}=req.body;
 if(!positiveInt(supplier_id)||!positiveInt(product_id)||!positiveInt(quantity)||!Number.isFinite(Number(purchase_unit_cost))||Number(purchase_unit_cost)<0||!clean(received_date))return res.status(400).json({message:'Supplier, product, positive quantity, cost and date are required.'});
 const r=await rows('INSERT INTO stock_entries(supplier_id,product_id,quantity,purchase_unit_cost,received_date,notes) VALUES(?,?,?,?,?,?)',[supplier_id,product_id,quantity,purchase_unit_cost,received_date,clean(notes)]);
 res.status(201).json({id:r.insertId,message:'Incoming stock recorded.'});
}));

app.get('/api/orders', wrap(async(req,res)=>{
 const status=clean(req.query.status);
 res.json(await rows(`SELECT o.*,v.vendor_name,v.business_name FROM orders o JOIN street_vendors v ON v.id=o.vendor_id WHERE (?='' OR o.status=?) ORDER BY o.order_date DESC`,[status,status]));
}));
app.get('/api/orders/:id', wrap(async(req,res)=>{
 const order=(await rows('SELECT o.*,v.vendor_name,v.business_name FROM orders o JOIN street_vendors v ON v.id=o.vendor_id WHERE o.id=?',[req.params.id]))[0];
 if(!order)return res.status(404).json({message:'Order not found.'});
 order.items=await rows(`SELECT oi.*,f.name fruit_name,b.name box_size FROM order_items oi JOIN products p ON p.id=oi.product_id JOIN fruits f ON f.id=p.fruit_id JOIN box_sizes b ON b.id=p.box_size_id WHERE oi.order_id=?`,[req.params.id]);
 res.json(order);
}));
app.post('/api/orders', allowRoles(...BOTH), wrap(async(req,res)=>{
 const {vendor_id,items,notes}=req.body;
 if(!positiveInt(vendor_id)||!Array.isArray(items)||items.length===0)return res.status(400).json({message:'Select a registered vendor and at least one order item.'});
 const conn=await pool.getConnection();
 try{
  await conn.beginTransaction();
  const [vendor]=await conn.execute('SELECT id FROM street_vendors WHERE id=? AND status="Active" FOR UPDATE',[vendor_id]);
  if(!vendor.length)throw Object.assign(new Error('Choose an active registered vendor.'),{status:400});
  let total=0;const prepared=[];
  for(const item of items){
   if(!positiveInt(item.product_id)||!positiveInt(item.quantity))throw Object.assign(new Error('Every item needs a product and quantity greater than zero.'),{status:400});
   const [p]=await conn.execute(`SELECT p.id,p.selling_price,
    (SELECT COALESCE(SUM(quantity),0) FROM stock_entries WHERE product_id=p.id) -
    (SELECT COALESCE(SUM(oi.quantity),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=p.id AND o.status='Completed') stock
    FROM products p WHERE p.id=? AND p.active=1 FOR UPDATE`,[item.product_id]);
   if(!p.length)throw Object.assign(new Error('One selected product is unavailable.'),{status:400});
   if(Number(item.quantity)>Number(p[0].stock))throw Object.assign(new Error(`Not enough stock for product ${item.product_id}. Available: ${p[0].stock}.`),{status:409});
   const unit=Number(p[0].selling_price); const subtotal=unit*Number(item.quantity); total+=subtotal;
   prepared.push({product_id:item.product_id,quantity:Number(item.quantity),unit_price:unit,subtotal});
  }
  const [orderResult]=await conn.execute('INSERT INTO orders(vendor_id,status,total_amount,notes,created_by) VALUES(?,"Pending",?,?,?)',[vendor_id,total,clean(notes),req.user.id]);
  for(const it of prepared)await conn.execute('INSERT INTO order_items(order_id,product_id,quantity,unit_price,subtotal) VALUES(?,?,?,?,?)',[orderResult.insertId,it.product_id,it.quantity,it.unit_price,it.subtotal]);
  await conn.commit();res.status(201).json({id:orderResult.insertId,total_amount:total,message:'Order created.'});
 }catch(e){await conn.rollback();throw e;}finally{conn.release();}
}));
app.put('/api/orders/:id/status', allowRoles(...BOTH), wrap(async(req,res)=>{
 const allowed=['Pending','Confirmed','Processing','Ready for Collection/Delivery','Completed','Cancelled'];
 const status=clean(req.body.status);if(!allowed.includes(status))return res.status(400).json({message:'Invalid order status.'});
 const conn=await pool.getConnection();
 try{
  await conn.beginTransaction();
  const [orderRows]=await conn.execute('SELECT * FROM orders WHERE id=? FOR UPDATE',[req.params.id]);
  if(!orderRows.length){await conn.rollback();return res.status(404).json({message:'Order not found.'});}
  const order=orderRows[0];
  if(order.status==='Completed' && status!=='Completed'){await conn.rollback();return res.status(409).json({message:'Completed orders cannot be reopened; use a stock reversal process.'});}
  if(status==='Completed' && order.status!=='Completed'){
   const [items]=await conn.execute('SELECT product_id,SUM(quantity) quantity FROM order_items WHERE order_id=? GROUP BY product_id',[order.id]);
   for(const item of items){
    const [stockRows]=await conn.execute(`SELECT
      (SELECT COALESCE(SUM(quantity),0) FROM stock_entries WHERE product_id=?) -
      (SELECT COALESCE(SUM(oi.quantity),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=? AND o.status='Completed') stock`,[item.product_id,item.product_id]);
    if(Number(item.quantity)>Number(stockRows[0].stock))throw Object.assign(new Error(`Insufficient stock for product ${item.product_id}.`),{status:409});
   }
  }
  await conn.execute('UPDATE orders SET status=? WHERE id=?',[status,order.id]);
  await conn.commit();res.json({message:'Order status updated.'});
 }catch(e){await conn.rollback();throw e;}finally{conn.release();}
}));
app.delete('/api/orders/:id', allowRoles(...ADMIN), wrap(async(req,res)=>{
 const result=await rows('DELETE FROM orders WHERE id=? AND status IN ("Pending","Cancelled")',[req.params.id]);
 if(!result.affectedRows)return res.status(409).json({message:'Only pending or cancelled orders can be deleted.'});
 res.json({message:'Order deleted.'});
}));

app.get('/api/dashboard', wrap(async(req,res)=>{
 const [fruit]=await rows('SELECT COUNT(*) total FROM fruits WHERE active=1');
 const [supplier]=await rows('SELECT COUNT(*) total FROM suppliers');
 const [vendor]=await rows('SELECT COUNT(*) total FROM street_vendors WHERE status="Active"');
 const productRows=await rows(`SELECT p.id,
 (SELECT COALESCE(SUM(quantity),0) FROM stock_entries WHERE product_id=p.id) -
 (SELECT COALESCE(SUM(oi.quantity),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=p.id AND o.status='Completed') stock
 FROM products p WHERE p.active=1`);
 const availableStock=(productRows||[]).reduce((sum,p)=>sum+Number(p.stock||0),0);
 const [orderCounts]=await rows(`SELECT COUNT(*) total_orders,
 COALESCE(SUM(status IN ('Pending','Confirmed','Processing','Ready for Collection/Delivery')),0) pending_orders,
 COALESCE(SUM(status='Completed'),0) completed_orders,
 COALESCE(SUM(CASE WHEN status='Completed' THEN total_amount ELSE 0 END),0) sales_value FROM orders`);
 res.json({totalFruits:fruit?.total||0,totalSuppliers:supplier?.total||0,totalVendors:vendor?.total||0,availableStock,...orderCounts});
}));
app.get('/api/reports', wrap(async(req,res)=>{
 const byFruit=await rows(`SELECT f.name fruit,COALESCE(SUM(CASE WHEN o.status='Completed' THEN oi.quantity ELSE 0 END),0) boxes_sold,COALESCE(SUM(CASE WHEN o.status='Completed' THEN oi.subtotal ELSE 0 END),0) sales FROM fruits f LEFT JOIN products p ON p.fruit_id=f.id LEFT JOIN order_items oi ON oi.product_id=p.id LEFT JOIN orders o ON o.id=oi.order_id GROUP BY f.id ORDER BY sales DESC`);
 const byBox=await rows(`SELECT b.name box_size,COALESCE(SUM(CASE WHEN o.status='Completed' THEN oi.quantity ELSE 0 END),0) boxes_sold,COALESCE(SUM(CASE WHEN o.status='Completed' THEN oi.subtotal ELSE 0 END),0) sales FROM box_sizes b LEFT JOIN products p ON p.box_size_id=b.id LEFT JOIN order_items oi ON oi.product_id=p.id LEFT JOIN orders o ON o.id=oi.order_id GROUP BY b.id ORDER BY b.id`);
 const byVendor=await rows(`SELECT v.vendor_name,COALESCE(SUM(CASE WHEN o.status='Completed' THEN o.total_amount ELSE 0 END),0) sales FROM street_vendors v LEFT JOIN orders o ON o.vendor_id=v.id GROUP BY v.id ORDER BY sales DESC`);
 const byProvince=await rows(`SELECT s.province,COALESCE(SUM(se.quantity*se.purchase_unit_cost),0) purchase_value,COALESCE(SUM(se.quantity),0) boxes_received FROM suppliers s LEFT JOIN stock_entries se ON se.supplier_id=s.id GROUP BY s.province ORDER BY purchase_value DESC`);
 const pending=await rows(`SELECT o.id,o.order_date,o.status,o.total_amount,v.vendor_name FROM orders o JOIN street_vendors v ON v.id=o.vendor_id WHERE o.status IN ('Pending','Confirmed','Processing','Ready for Collection/Delivery') ORDER BY o.order_date DESC`);
 const completed=await rows(`SELECT o.id,o.order_date,o.status,o.total_amount,v.vendor_name FROM orders o JOIN street_vendors v ON v.id=o.vendor_id WHERE o.status='Completed' ORDER BY o.order_date DESC`);
 const byDate=await rows(`SELECT DATE(order_date) sale_date,COALESCE(SUM(total_amount),0) sales FROM orders WHERE status='Completed' GROUP BY DATE(order_date) ORDER BY sale_date DESC LIMIT 30`);
 res.json({byFruit,byBox,byVendor,byProvince,pending,completed,byDate});
}));

app.use((err,req,res,next)=>{
 console.error(err);
 if(err.code==='ER_DUP_ENTRY')return res.status(409).json({message:'That record already exists. Check for duplicate names or fruit/box combinations.'});
 if(err.code==='ER_NO_REFERENCED_ROW_2')return res.status(400).json({message:'Choose a valid related record.'});
 res.status(err.status||500).json({message:err.status?err.message:'Server error. Check backend console and database connection.'});
});
app.listen(PORT,()=>console.log(`Batloung Fruits API running on http://localhost:${PORT}`));
