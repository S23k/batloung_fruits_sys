import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Allow password to be passed via argument: `node setupDb.js <password>`
const passwordArg = process.argv[2];
const dbPassword = passwordArg !== undefined ? passwordArg : (process.env.DB_PASSWORD || '');
const dbHost = process.env.DB_HOST || 'localhost';
const dbPort = Number(process.env.DB_PORT || 3306);
const dbUser = process.env.DB_USER || 'root';
const dbName = process.env.DB_NAME || 'batloung_fruits';

console.log('Connecting to MySQL at ' + dbHost + ':' + dbPort + ' as user ' + dbUser + '...');

async function run() {
  let conn;
  try {
    conn = await mysql.createConnection({
      host: dbHost,
      port: dbPort,
      user: dbUser,
      password: dbPassword,
      multipleStatements: true
    });
    console.log('Successfully connected to MySQL server!');
  } catch (err) {
    console.error('Failed to connect to MySQL:', err.message);
    if (err.code === 'ER_ACCESS_DENIED_ERROR') {
      console.log('\nTIP: Provide your MySQL root password using:');
      console.log('  node setupDb.js YOUR_PASSWORD\n');
    }
    process.exit(1);
  }

  try {
    // If passwordArg was provided and worked, update backend/.env
    if (passwordArg !== undefined) {
      const envPath = path.join(__dirname, '.env');
      let envContent = '';
      if (fs.existsSync(envPath)) {
        envContent = fs.readFileSync(envPath, 'utf8');
      } else {
        const examplePath = path.join(__dirname, '.env.example');
        envContent = fs.existsSync(examplePath) ? fs.readFileSync(examplePath, 'utf8') : '';
      }
      if (envContent.includes('DB_PASSWORD=')) {
        envContent = envContent.replace(/DB_PASSWORD=.*/g, `DB_PASSWORD=${passwordArg}`);
      } else {
        envContent += `\nDB_PASSWORD=${passwordArg}\n`;
      }
      fs.writeFileSync(envPath, envContent, 'utf8');
      console.log('Updated backend/.env with the working MySQL password.');
    }

    const schemaPath = path.join(__dirname, '..', 'database', 'schema.sql');
    if (!fs.existsSync(schemaPath)) {
      throw new Error(`Schema file not found at: ${schemaPath}`);
    }

    const sql = fs.readFileSync(schemaPath, 'utf8');
    console.log('Executing database/schema.sql...');
    await conn.query(sql);

    // Verify street_vendors has latitude and longitude
    const [cols] = await conn.query(`
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'street_vendors' AND COLUMN_NAME IN ('latitude', 'longitude')
    `, [dbName]);

    if (cols.length < 2) {
      console.log('Adding latitude and longitude columns to street_vendors...');
      try {
        await conn.query(`
          ALTER TABLE \`${dbName}\`.street_vendors 
          ADD COLUMN latitude DECIMAL(10, 8) NULL,
          ADD COLUMN longitude DECIMAL(11, 8) NULL
        `);
      } catch (e) {
        // column may already exist
      }
    }

    console.log('Database ' + dbName + ' is fully configured and seeded!');
    console.log('Ready to run the backend: npm run dev');
  } catch (err) {
    console.error('Database setup failed:', err.message);
    process.exit(1);
  } finally {
    if (conn) await conn.end();
  }
}

run();
