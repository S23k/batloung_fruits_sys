@echo off
title Batloung Fruits API (Port 5000)
cd /d "%~dp0"
echo Starting Batloung Fruits API on http://localhost:5000...
node server.js
pause
