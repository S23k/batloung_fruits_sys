CREATE DATABASE IF NOT EXISTS batloung_fruits CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE batloung_fruits;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS stock_entries;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS street_vendors;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS fruits;
DROP TABLE IF EXISTS box_sizes;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('Administrator','Sales') NOT NULL DEFAULT 'Sales',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fruits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name ENUM('Apples','Bananas','Oranges','Mangoes','Grapes') NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT '',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE box_sizes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name ENUM('Small','Medium','Large') NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT ''
);

CREATE TABLE suppliers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  province ENUM('Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','Northern Cape','North West','Western Cape') NOT NULL,
  contact_person VARCHAR(120) NOT NULL,
  telephone VARCHAR(40) NOT NULL,
  email VARCHAR(190) DEFAULT '',
  physical_address VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE street_vendors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vendor_name VARCHAR(150) NOT NULL,
  business_name VARCHAR(150) NOT NULL,
  telephone VARCHAR(40) NOT NULL,
  location_area VARCHAR(150) NOT NULL,
  latitude DECIMAL(10, 8) NULL,
  longitude DECIMAL(11, 8) NULL,
  registration_date DATE NOT NULL,
  status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fruit_id INT NOT NULL,
  box_size_id INT NOT NULL,
  selling_price DECIMAL(10,2) NOT NULL CHECK (selling_price >= 0),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE KEY unique_fruit_box (fruit_id, box_size_id),
  CONSTRAINT fk_products_fruit FOREIGN KEY (fruit_id) REFERENCES fruits(id),
  CONSTRAINT fk_products_box FOREIGN KEY (box_size_id) REFERENCES box_sizes(id)
);

CREATE TABLE stock_entries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  supplier_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  purchase_unit_cost DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (purchase_unit_cost >= 0),
  received_date DATE NOT NULL,
  notes VARCHAR(255) DEFAULT '',
  CONSTRAINT fk_stock_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
  CONSTRAINT fk_stock_product FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vendor_id INT NOT NULL,
  order_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('Pending','Confirmed','Processing','Ready for Collection/Delivery','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  notes VARCHAR(255) DEFAULT '',
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_vendor FOREIGN KEY (vendor_id) REFERENCES street_vendors(id),
  CONSTRAINT fk_orders_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
  subtotal DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_items_product FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Demo password hashes generated with bcryptjs:
-- Admin123! = $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy
-- Sales123! = $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy
-- The seed script below uses known bcrypt hashes; if login fails in your environment,
-- run `npm run seed-users` from backend to regenerate compatible hashes.
INSERT INTO users (name,email,password_hash,role) VALUES
('System Administrator','admin@batloung.co.za','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','Administrator'),
('Sales User','sales@batloung.co.za','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','Sales');

INSERT INTO fruits (name,description) VALUES
('Apples','Available seasonally from approved source provinces'),
('Bananas','Available seasonally from approved source provinces'),
('Oranges','Available seasonally from approved source provinces'),
('Mangoes','Available seasonally from approved source provinces'),
('Grapes','Available seasonally from approved source provinces');

INSERT INTO box_sizes (name,description) VALUES
('Small','For vendors with limited capital or lower daily demand'),
('Medium','For vendors with moderate customer demand'),
('Large','For vendors purchasing higher volumes');

INSERT INTO suppliers (name,province,contact_person,telephone,email,physical_address) VALUES
('Cape Fresh Produce','Western Cape','Mpho Ndlovu','021 555 0101','cape@example.co.za','Cape Town, Western Cape'),
('Limpopo Orchard Co.','Limpopo','Thabo Mokoena','015 555 0102','limpopo@example.co.za','Polokwane, Limpopo'),
('Mpumalanga Fruit Growers','Mpumalanga','Lerato Molefe','013 555 0103','mpu@example.co.za','Mbombela, Mpumalanga');

INSERT INTO street_vendors (vendor_name,business_name,telephone,location_area,latitude,longitude,registration_date,status) VALUES
('Masechaba Mokoena','Masechaba Street Stall','+266 5800 1001','Maseru Central Market',-29.31680,27.48550,'2026-01-10','Active'),
('Kabelo Thabane','Kabelo Fresh Stand','+266 5800 1002','Thetsane Industrial Area',-29.35240,27.47210,'2026-02-15','Active'),
('Lineo Ramoshebi','Lineo Fruit Oasis','+266 5800 1003','Cathedral Area, Maseru',-29.31120,27.49810,'2026-03-01','Active'),
('Nkau Molapo','Nkau Corner Fresh','+266 5800 1004','Peka Taxi Rank, Maseru',-29.32450,27.46820,'2026-03-12','Active');

INSERT INTO products (fruit_id,box_size_id,selling_price) SELECT f.id,b.id,
CASE WHEN f.name='Apples' AND b.name='Small' THEN 80.00
WHEN f.name='Apples' AND b.name='Medium' THEN 145.00
WHEN f.name='Apples' AND b.name='Large' THEN 220.00
WHEN b.name='Small' THEN 90.00 WHEN b.name='Medium' THEN 160.00 ELSE 240.00 END
FROM fruits f CROSS JOIN box_sizes b;

INSERT INTO stock_entries (supplier_id,product_id,quantity,purchase_unit_cost,received_date,notes)
SELECT 1,p.id,50,45.00,CURDATE(),'Initial demonstration stock' FROM products p;
