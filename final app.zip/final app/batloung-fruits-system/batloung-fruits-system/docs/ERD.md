# Entity Relationship Diagram (ERD)

```mermaid
erDiagram
    USERS ||--o{ ORDERS : creates
    STREET_VENDORS ||--o{ ORDERS : places
    ORDERS ||--|{ ORDER_ITEMS : contains
    PRODUCTS ||--o{ ORDER_ITEMS : ordered_as
    FRUITS ||--o{ PRODUCTS : defines
    BOX_SIZES ||--o{ PRODUCTS : configures
    SUPPLIERS ||--o{ STOCK_ENTRIES : supplies
    PRODUCTS ||--o{ STOCK_ENTRIES : received_as

    USERS {
      int id PK
      varchar name
      varchar email UK
      varchar password_hash
      enum role
    }
    FRUITS {
      int id PK
      enum name UK
      boolean active
    }
    BOX_SIZES {
      int id PK
      enum name UK
    }
    PRODUCTS {
      int id PK
      int fruit_id FK
      int box_size_id FK
      decimal selling_price
      boolean active
    }
    SUPPLIERS {
      int id PK
      varchar name
      enum province
      varchar contact_person
      varchar telephone
      varchar email
      varchar physical_address
    }
    STREET_VENDORS {
      int id PK
      varchar vendor_name
      varchar business_name
      varchar telephone
      varchar location_area
      decimal latitude
      decimal longitude
      date registration_date
      enum status
    }
    STOCK_ENTRIES {
      int id PK
      int supplier_id FK
      int product_id FK
      int quantity
      decimal purchase_unit_cost
      date received_date
    }
    ORDERS {
      int id PK
      int vendor_id FK
      int created_by FK
      datetime order_date
      enum status
      decimal total_amount
    }
    ORDER_ITEMS {
      int id PK
      int order_id FK
      int product_id FK
      int quantity
      decimal unit_price
      decimal subtotal
    }
```

## Relationship explanation
- A supplier can have many stock entries; every stock entry references one supplier.
- A product is one fruit combined with one box size. The fruit/box pair is unique.
- A product can appear in many stock entries and order items.
- A registered street vendor can place many orders.
- An order must contain one or more order items.
- Each order item refers to one saleable product.
- A user who creates an order is recorded where available.
