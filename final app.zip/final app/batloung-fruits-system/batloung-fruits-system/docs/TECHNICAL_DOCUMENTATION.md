# Batloung Fruits Distribution Management System
## Technical documentation — DIWA2110

### 1. Purpose
The system manages suppliers, fruits, fruit-and-box-size products, incoming stock, street vendors, orders, and sales reports for Batloung Fruits. It replaces fragmented manual records with related database records and a web interface.

### 2. Technology architecture
1. React renders the browser interface.
2. The frontend calls JSON REST endpoints hosted by Express.
3. Express validates requests, enforces role permissions, and applies business rules.
4. MySQL stores normalized relational data with primary and foreign keys.

### 3. Modules
- Dashboard: fruit/supplier/vendor counts, available stock, order totals, pending/completed orders and sales value.
- Products & Fruits: the five permitted fruit types; each product is a unique fruit + box size configuration with a selling price.
- Suppliers: contact details and one of South Africa's nine provinces.
- Street Vendors: vendor identity, business, phone, Maseru area, geographic coordinates (latitude & longitude), distance calculation, registration date and status.
- Location & Mapping System: interactive Leaflet map centered on Maseru, Lesotho; features photorealistic Live Satellite imagery (Esri World Imagery + street networks & place labels), Realistic GIS Streets, and OpenStreetMap; displays Batloung Fruits Central Depot (HQ) at Kingsway Road, Maseru with 2km/5km distribution radii; tracks street vendor locations; calculates great-circle distance in kilometers via the Haversine formula; computes multi-modal travel time to destination (car, bicycle, and on foot); includes automated "Nearest to HQ" vendor detection with spotlight route zooming; provides automated destination name resolution upon live GPS pinging or click-to-pin map placement with expanded Maseru area presets.
- Stock: incoming deliveries tied to suppliers and products.
- Orders: registered vendor, at least one item, quantity, price, subtotal, total and status.
- Reports: sales by fruit, box size, vendor and date; purchases by province; pending and completed orders.
- Security: JWT authentication and Administrator/Sales roles.

### 4. Business rules
- Only Apples, Bananas, Oranges, Mangoes and Grapes are initially supported.
- Box sizes are Small, Medium and Large.
- Product selling prices cannot be negative.
- Vendors must be registered and active to place an order.
- Order item quantities must be positive.
- The API checks available stock before creating an order.
- Stock is reduced when an order changes to Completed.
- Cancelled orders do not deduct stock.
- Completed orders cannot be reopened in this educational implementation.
- The backend calculates subtotals and totals; it does not trust client-supplied totals.
- Required fields and province values are validated on the server.

### 5. Main REST endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Service health check |
| GET | `/api/system/location` | Batloung Fruits Central Depot coordinates & info |
| POST | `/api/auth/login` | Sign in and receive JWT |
| GET/POST | `/api/fruits` | List/create fruit |
| GET/PUT/DELETE | `/api/fruits/:id` | Read/update/delete fruit |
| GET | `/api/box-sizes` | List box sizes |
| GET/POST | `/api/products` | List/create fruit + box products |
| PUT | `/api/products/:id` | Update product/price/active state |
| GET/POST | `/api/suppliers` | List/create suppliers |
| PUT/DELETE | `/api/suppliers/:id` | Update/delete supplier |
| GET/POST | `/api/vendors` | List/register vendors |
| PUT/DELETE | `/api/vendors/:id` | Update/delete vendor |
| GET/POST | `/api/stock` | View/record incoming stock |
| GET/POST | `/api/orders` | List/create orders |
| GET | `/api/orders/:id` | View an order with line items |
| PUT | `/api/orders/:id/status` | Change order status |
| GET | `/api/dashboard` | Dashboard metrics |
| GET | `/api/reports` | Report datasets |

### 6. User roles
**Administrator:** manage fruit/product catalogue, suppliers, stock, vendors, orders, and reports.
**Sales:** view products/suppliers/vendors/stock/orders/reports, register vendors, create orders, and update order status. Deletion and catalogue/stock changes are restricted to Administrator.

### 7. Setup and testing
Follow the instructions in the root README. Test the API health endpoint, sign in with a demo account, create a supplier, receive stock, create an order, then mark it Completed and verify available stock decreases. Test cancellation and confirm it does not deduct stock.

### 8. Limitations and future improvements
- Add pagination, more granular permissions, password reset and user administration.
- Add stock adjustment/reversal workflow and audit logs.
- Add PDF/CSV report exports and visual charts.
- Add automated API/integration tests.
- Deploy frontend/API/database with production secrets and HTTPS.
