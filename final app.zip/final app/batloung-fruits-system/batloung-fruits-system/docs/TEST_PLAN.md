# Test plan

| ID | Test | Expected result |
|---|---|---|
| T01 | Sign in with correct demo credentials | JWT session opens dashboard |
| T02 | Sign in with incorrect password | API returns 401 and an error |
| T03 | Create supplier with valid province | Supplier is saved |
| T04 | Create supplier with invalid/missing province | API rejects request |
| T05 | Add a product with fruit and box size | Product is saved with a selling price |
| T06 | Receive 10 boxes from a supplier | Stock history records 10 incoming boxes |
| T07 | Create order for a registered active vendor | Order and item are saved; total calculated |
| T08 | Create order with quantity zero | API rejects the order |
| T09 | Order more boxes than available | API returns a stock error |
| T10 | Mark order Completed | Available stock decreases by the ordered quantity |
| T11 | Cancel an order | Available stock is not reduced |
| T12 | Delete a supplier with stock history | API prevents deletion |
| T13 | Search vendors/suppliers/products | Matching records are shown |
| T14 | Open reports | Report tables show the current database results |
| T15 | Sign in as Sales and try deleting a supplier | API returns 403 |
