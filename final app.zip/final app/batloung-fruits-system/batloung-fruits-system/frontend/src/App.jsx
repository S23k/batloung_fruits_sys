import React, { useEffect, useMemo, useState } from 'react';
import { LayoutDashboard, Apple, Truck, Store, Boxes, ShoppingCart, BarChart3, LogOut, Search, Plus, RefreshCw, Menu, X, Leaf, ChevronDown, CircleCheck, AlertCircle, MapPin, Map, List, Navigation } from 'lucide-react';
import { VendorMapView, LocationPickerModalTool, calculateDistanceKm, calculateTravelTimes, BATLOUNG_DEPOT } from './VendorMap.jsx';

const API = 'http://localhost:5000/api';
const provinces = ['Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','Northern Cape','North West','Western Cape'];
const fruitNames = ['Apples','Bananas','Oranges','Mangoes','Grapes'];
const statuses = ['Pending','Confirmed','Processing','Ready for Collection/Delivery','Completed','Cancelled'];
const money = n => new Intl.NumberFormat('en-ZA',{style:'currency',currency:'ZAR'}).format(Number(n||0));
const dateToday = () => new Date().toISOString().slice(0,10);

function App(){
 const [token,setToken]=useState(localStorage.getItem('bf_token')||'');
 const [user,setUser]=useState(JSON.parse(localStorage.getItem('bf_user')||'null'));
 const [page,setPage]=useState('Dashboard');
 const [data,setData]=useState({dashboard:{},fruits:[],products:[],boxSizes:[],suppliers:[],vendors:[],stock:[],orders:[],reports:{}});
 const [loading,setLoading]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const [search,setSearch]=useState(''),[modal,setModal]=useState(null),[mobileNav,setMobileNav]=useState(false);
 const isAdmin=user?.role==='Administrator';
 const nav=[['Dashboard',LayoutDashboard],['Products & Fruits',Apple],['Suppliers',Truck],['Street Vendors',Store],['Vendor Map',MapPin],['Stock',Boxes],['Orders',ShoppingCart],['Reports',BarChart3]];
 const request=async(path,options={})=>{
  const res=await fetch(`${API}${path}`,{...options,headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`} : {}),...(options.headers||{})}});
  const body=await res.json().catch(()=>({}));
  if(!res.ok)throw new Error(body.message||'Request failed');return body;
 };
 const refresh=async()=>{
  if(!token)return;setLoading(true);setError('');
  try{
   const [dashboard,fruits,products,boxSizes,suppliers,vendors,stock,orders,reports]=await Promise.all([
    request('/dashboard'),request('/fruits'),request('/products'),request('/box-sizes'),request('/suppliers'),request('/vendors'),request('/stock'),request('/orders'),request('/reports')
   ]);
   setData({dashboard,fruits,products,boxSizes,suppliers,vendors,stock,orders,reports});
  }catch(e){setError(e.message);}finally{setLoading(false);}
 };
 useEffect(()=>{if(token)refresh();},[token]);
 const logout=()=>{localStorage.removeItem('bf_token');localStorage.removeItem('bf_user');setToken('');setUser(null);};
 const toast=msg=>{setNotice(msg);setTimeout(()=>setNotice(''),3500);};
 if(!token)return <Login onLogin={(t,u)=>{localStorage.setItem('bf_token',t);localStorage.setItem('bf_user',JSON.stringify(u));setToken(t);setUser(u);}} />;

 const save=async(path,method,body)=>{try{await request(path,{method,body:JSON.stringify(body)});setModal(null);toast('Changes saved successfully.');await refresh();}catch(e){setError(e.message);}};
 const filtered=(list,fields)=>list.filter(item=>fields.some(f=>String(item[f]??'').toLowerCase().includes(search.toLowerCase())));
 const titleIcon=nav.find(n=>n[0]===page)?.[1]||LayoutDashboard;
 const openAdd=()=>setModal({type:page==='Products & Fruits'?'product':page==='Suppliers'?'supplier':page==='Street Vendors'?'vendor':page==='Stock'?'stock':page==='Orders'?'order':'fruit'});
 const pageContent=()=>{
  if(page==='Dashboard')return <Dashboard stats={data.dashboard} orders={data.orders} products={data.products} setPage={setPage}/>;
  if(page==='Products & Fruits')return <Products products={data.products} fruits={data.fruits} boxSizes={data.boxSizes} isAdmin={isAdmin} search={search} setSearch={setSearch} onAdd={openAdd} onEdit={p=>setModal({type:'product',item:p})} onDelete={p=>save(`/products/${p.id}`,'PUT',{fruit_id:p.fruit_id,box_size_id:p.box_size_id,selling_price:p.selling_price,active:false})}/>;
  if(page==='Suppliers')return <Suppliers list={filtered(data.suppliers,['name','province','contact_person','telephone'])} isAdmin={isAdmin} search={search} setSearch={setSearch} onAdd={openAdd} onEdit={x=>setModal({type:'supplier',item:x})} onDelete={x=>{if(confirm('Delete this supplier?'))save(`/suppliers/${x.id}`,'DELETE',{});}}/>;
  if(page==='Street Vendors')return <Vendors list={filtered(data.vendors,['vendor_name','business_name','location_area'])} isAdmin={isAdmin} search={search} setSearch={setSearch} onAdd={openAdd} onEdit={x=>setModal({type:'vendor',item:x})} onDelete={x=>{if(confirm('Delete this vendor?'))save(`/vendors/${x.id}`,'DELETE',{});}} onOpenMap={()=>setPage('Vendor Map')}/>;
  if(page==='Vendor Map')return <VendorMapView vendors={data.vendors} onEditVendor={x=>setModal({type:'vendor',item:x})} depot={BATLOUNG_DEPOT}/>;
  if(page==='Stock')return <Stock list={data.stock} products={data.products} suppliers={data.suppliers} isAdmin={isAdmin} onAdd={openAdd}/>;
  if(page==='Orders')return <Orders list={data.orders} vendors={data.vendors} products={data.products} isAdmin={isAdmin} onAdd={openAdd} onStatus={async(o,status)=>{try{await request(`/orders/${o.id}/status`,{method:'PUT',body:JSON.stringify({status})});toast('Order status updated.');refresh();}catch(e){setError(e.message);}}} onView={async o=>{try{const detail=await request(`/orders/${o.id}`);setModal({type:'order-detail',item:detail});}catch(e){setError(e.message);}}}/>;
  if(page==='Reports')return <Reports reports={data.reports}/>;
 };
 return <div className="app-shell">
  <aside className={`sidebar ${mobileNav?'open':''}`}><div className="brand"><div className="brand-mark"><Leaf size={24}/></div><div><strong>Batloung</strong><span>FRUITS DISTRIBUTION</span></div><button className="mobile-close" onClick={()=>setMobileNav(false)}><X size={19}/></button></div>
   <div className="nav-label">WORKSPACE</div>{nav.map(([label,Icon])=><button key={label} className={`nav-item ${page===label?'active':''}`} onClick={()=>{setPage(label);setSearch('');setMobileNav(false);}}><Icon size={18}/><span>{label}</span>{label==='Orders'&&data.dashboard.pending_orders>0&&<i>{data.dashboard.pending_orders}</i>}</button>)}
   <div className="sidebar-bottom"><div className="status-dot"/> <div><b>System online</b><span>API connection ready</span></div></div>
  </aside>
  {mobileNav&&<div className="scrim" onClick={()=>setMobileNav(false)}/>}
  <main className="main-area"><header className="topbar"><button className="mobile-menu" onClick={()=>setMobileNav(true)}><Menu/></button><div className="crumb">Workspace <span>/</span> <b>{page}</b></div><div className="top-actions"><button className="icon-button" title="Refresh data" onClick={refresh}><RefreshCw size={17}/></button><div className="user-badge"><div className="avatar">{user?.name?.split(' ').map(x=>x[0]).slice(0,2).join('')}</div><div className="user-info"><b>{user?.name}</b><span>{user?.role}</span></div><ChevronDown size={15}/></div><button className="icon-button" title="Sign out" onClick={logout}><LogOut size={17}/></button></div></header>
   <section className="page-wrap"><div className="page-heading"><div><div className="eyebrow">BATLOUNG FRUITS · OPERATIONS</div><h1>{page}</h1><p>{({Dashboard:'A clear view of your distribution business.', 'Products & Fruits':'Manage fruit varieties, box configurations and selling prices.',Suppliers:'Keep supplier contacts and source provinces up to date.','Street Vendors':'Manage registered street vendors across Maseru.','Vendor Map':'Interactive map showing vendor locations, routes and distances from Batloung Fruits Central Depot.',Stock:'Record deliveries and monitor available stock.',Orders:'Create orders and track fulfilment from pending to completed.',Reports:'Review sales performance and purchasing activity.'})[page]}</p></div>{['Products & Fruits','Suppliers','Street Vendors','Vendor Map','Stock','Orders'].includes(page)&&<button className="primary-btn" onClick={openAdd}><Plus size={17}/>{page==='Products & Fruits'?'Add product':page==='Suppliers'?'Add supplier':['Street Vendors','Vendor Map'].includes(page)?'Register vendor':page==='Stock'?'Receive stock':'New order'}</button>}</div>
   {error&&<div className="alert error"><AlertCircle size={17}/>{error}<button onClick={()=>setError('')}>×</button></div>}{notice&&<div className="alert success"><CircleCheck size={17}/>{notice}</div>}
   {loading?<div className="loading"><span className="spinner"/>Loading your business data…</div>:pageContent()}
   <footer>© {new Date().getFullYear()} Batloung Fruits <span>Distribution Management System · DIWA2110</span></footer>
   </section>
  </main>
  {modal&&<Modal modal={modal} data={data} onClose={()=>setModal(null)} onSave={save} request={request} isAdmin={isAdmin}/>}
 </div>;
}

function Login({onLogin}){
 const [email,setEmail]=useState('admin@batloung.co.za'),[password,setPassword]=useState('Admin123!'),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const submit=async e=>{e.preventDefault();setBusy(true);setError('');try{const r=await fetch(`${API}/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});const d=await r.json();if(!r.ok)throw new Error(d.message||'Unable to sign in');onLogin(d.token,d.user);}catch(e){setError(e.message==='Failed to fetch'?'Cannot reach API. Start the backend on port 5000 first.':e.message);}finally{setBusy(false);}};
 return <div className="login-screen"><div className="login-art"><div className="login-brand"><div className="brand-mark"><Leaf size={26}/></div><span>BATLOUNG <b>FRUITS</b></span></div><div className="art-copy"><span className="pill">FRESH STOCK. SMARTER DISTRIBUTION.</span><h1>Every box has<br/>a <em>destination.</em></h1><p>One place to manage suppliers, stock, vendors and every order that moves your business forward.</p><div className="fruit-orbit"><span>🍎</span><span>🍌</span><span>🍊</span><span>🥭</span><span>🍇</span></div></div><div className="art-foot">SUPPLY WITH CONFIDENCE · MASERU</div></div><div className="login-panel"><form className="login-form" onSubmit={submit}><div className="eyebrow">WELCOME BACK</div><h2>Sign in to your workspace</h2><p className="muted">Use your assigned account to continue.</p>{error&&<div className="alert error">{error}</div>}<label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/></label><button className="primary-btn full" disabled={busy}>{busy?'Signing in…':'Sign in'} <span>→</span></button><div className="demo-login"><b>Demo access</b><span>Admin: admin@batloung.co.za / Admin123!</span><span>Sales: sales@batloung.co.za / Sales123!</span></div><small>Educational demonstration · Change demo credentials before deployment.</small></form></div></div>;
}
function StatCard({label,value,sub,icon:Icon,tone='green'}){return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={20}/></div><div className="stat-label">{label}</div><div className="stat-value">{value??'—'}</div><div className="stat-sub">{sub}</div></div>}
function Dashboard({stats,orders,products,setPage}){
 const recent=orders.slice(0,5);const stockTotal=products.reduce((n,p)=>n+Number(p.stock||0),0);
 return <><div className="welcome-banner"><div><span className="banner-tag">OPERATIONS OVERVIEW</span><h2>Good work starts with a fresh view.</h2><p>Track today's stock, orders and sales from one dashboard.</p></div><div className="banner-fruits">🍎 🍊 🍇</div></div><div className="stats-grid"><StatCard label="Active fruit types" value={stats.totalFruits} sub="Across your catalogue" icon={Apple}/><StatCard label="Suppliers" value={stats.totalSuppliers} sub="South African source partners" icon={Truck} tone="blue"/><StatCard label="Registered vendors" value={stats.totalVendors} sub="Active vendor accounts" icon={Store} tone="orange"/><StatCard label="Available boxes" value={stockTotal.toLocaleString()} sub="Across all product sizes" icon={Boxes} tone="purple"/><StatCard label="Total orders" value={stats.total_orders||0} sub="All recorded orders" icon={ShoppingCart}/><StatCard label="Pending orders" value={stats.pending_orders||0} sub="Awaiting completion" icon={RefreshCw} tone="orange"/><StatCard label="Completed orders" value={stats.completed_orders||0} sub="Successfully fulfilled" icon={CircleCheck} tone="blue"/><StatCard label="Sales value" value={money(stats.sales_value)} sub="Completed orders only" icon={BarChart3} tone="purple"/></div><div className="content-grid"><div className="panel"><div className="panel-head"><div><h3>Recent orders</h3><p>Latest activity across your vendors</p></div><button className="text-btn" onClick={()=>setPage('Orders')}>View all →</button></div><OrderTable list={recent} compact/></div><div className="panel quick-panel"><div className="panel-head"><div><h3>Quick actions</h3><p>Jump into daily operations</p></div></div>{[['Receive stock','Record a supplier delivery','Stock',Boxes],['Register vendor','Add a new street vendor','Street Vendors',Store],['Create order','Prepare a vendor order','Orders',ShoppingCart],['View reports','Review business performance','Reports',BarChart3]].map(([a,b,p,I])=><button className="quick-action" key={a} onClick={()=>setPage(p)}><span className="quick-icon"><I size={18}/></span><span><b>{a}</b><small>{b}</small></span><span className="arrow">↗</span></button>)}</div></div></>;
}
function SearchBar({value,onChange,placeholder='Search records…'}){return <div className="search-box"><Search size={17}/><input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/>{value&&<button onClick={()=>onChange('')}>×</button>}</div>}
function TablePanel({title,description,children,search,setSearch,placeholder,empty='No records found.'}){return <div className="panel table-panel"><div className="panel-head"><div><h3>{title}</h3><p>{description}</p></div>{search!==undefined&&<SearchBar value={search} onChange={setSearch} placeholder={placeholder}/>}</div>{children}</div>}
function Products({products,fruits,boxSizes,isAdmin,search,setSearch,onAdd,onEdit,onDelete}){
 const list=products.filter(p=>`${p.fruit_name} ${p.box_size}`.toLowerCase().includes(search.toLowerCase()));
 return <TablePanel title="Saleable product catalogue" description={`${products.length} fruit + box-size configurations`} search={search} setSearch={setSearch} placeholder="Search fruit or box size"><div className="table-scroll"><table><thead><tr><th>Product</th><th>Box size</th><th>Unit price</th><th>Available stock</th><th>Status</th>{isAdmin&&<th>Actions</th>}</tr></thead><tbody>{list.map(p=><tr key={p.id}><td><div className="product-cell"><span className="fruit-emoji">{({'Apples':'🍎','Bananas':'🍌','Oranges':'🍊','Mangoes':'🥭','Grapes':'🍇'})[p.fruit_name]}</span><div><b>{p.fruit_name}</b><small>SKU BF-{String(p.id).padStart(3,'0')}</small></div></div></td><td><span className={`size-chip ${p.box_size.toLowerCase()}`}>{p.box_size}</span></td><td className="price">{money(p.selling_price)}</td><td><b>{p.stock}</b> <small>boxes</small></td><td><span className={`badge ${p.active?'completed':'cancelled'}`}>{p.active?'Active':'Inactive'}</span></td>{isAdmin&&<td><div className="row-actions"><button onClick={()=>onEdit(p)}>Edit</button>{p.active&&<button className="danger-link" onClick={()=>onDelete(p)}>Deactivate</button>}</div></td>}</tr>)}</tbody></table>{!list.length&&<Empty/>}</div><div className="table-foot">Prices are in South African rand (ZAR). Stock changes when an order is completed.</div></TablePanel>;
}
function Suppliers({list,isAdmin,search,setSearch,onAdd,onEdit,onDelete}){return <TablePanel title="Supplier directory" description={`${list.length} matching supplier records`} search={search} setSearch={setSearch} placeholder="Search suppliers…"><div className="table-scroll"><table><thead><tr><th>Supplier</th><th>Province</th><th>Contact person</th><th>Telephone</th><th>Email</th>{isAdmin&&<th>Actions</th>}</tr></thead><tbody>{list.map(s=><tr key={s.id}><td><b>{s.name}</b><small className="block">{s.physical_address}</small></td><td><span className="province-chip">{s.province}</span></td><td>{s.contact_person}</td><td>{s.telephone}</td><td>{s.email||'—'}</td>{isAdmin&&<td><div className="row-actions"><button onClick={()=>onEdit(s)}>Edit</button><button className="danger-link" onClick={()=>onDelete(s)}>Delete</button></div></td>}</tr>)}</tbody></table>{!list.length&&<Empty/>}</div></TablePanel>}
function Vendors({list,isAdmin,search,setSearch,onAdd,onEdit,onDelete,onOpenMap}){
  const [viewMode,setViewMode]=useState('table');
  const mappedCount=list.filter(v=>v.latitude!=null&&v.longitude!=null&&!isNaN(Number(v.latitude))&&!isNaN(Number(v.longitude))).length;
  return <div>
    <div className="view-mode-bar">
      <div className="view-mode-toggles">
        <button type="button" className={`view-tab-btn ${viewMode==='table'?'active':''}`} onClick={()=>setViewMode('table')}>
          <List size={14}/> Table list ({list.length})
        </button>
        <button type="button" className={`view-tab-btn ${viewMode==='map'?'active':''}`} onClick={()=>setViewMode('map')}>
          <Map size={14}/> Map view ({mappedCount} mapped)
        </button>
      </div>
      <div className="depot-info-pill">
        🏢 Depot: <b>Batloung Central (Kingsway, Maseru)</b>
      </div>
    </div>

    {viewMode==='map' ? (
      <VendorMapView vendors={list} onEditVendor={onEdit} depot={BATLOUNG_DEPOT}/>
    ) : (
      <TablePanel title="Registered street vendors" description={`${list.length} vendor accounts across Maseru`} search={search} setSearch={setSearch} placeholder="Search vendors…">
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Vendor</th>
                <th>Business name</th>
                <th>Telephone</th>
                <th>Location / area</th>
                <th>Distance from Depot</th>
                <th>Registered</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {list.map(v=><tr key={v.id}>
                <td>
                  <div className="vendor-cell">
                    <span className="avatar small">{v.vendor_name.split(' ').map(x=>x[0]).slice(0,2).join('')}</span>
                    <b>{v.vendor_name}</b>
                  </div>
                </td>
                <td>{v.business_name}</td>
                <td>{v.telephone}</td>
                <td>{v.location_area}</td>
                <td>
                  {v.distance_km!=null ? (
                    <button type="button" className="table-distance-pill" onClick={()=>setViewMode('map')} title="Click to view on map and travel times">
                      <Navigation size={12}/> {v.distance_km} km · 🚗 {calculateTravelTimes(v.distance_km).car}
                    </button>
                  ) : (
                    <button type="button" className="table-pin-prompt" onClick={()=>onEdit(v)} title="Click to pin coordinates">
                      + Pin on map
                    </button>
                  )}
                </td>
                <td>{String(v.registration_date).slice(0,10)}</td>
                <td><span className={`badge ${v.status==='Active'?'completed':'cancelled'}`}>{v.status}</span></td>
                <td>
                  <div className="row-actions">
                    <button onClick={()=>onEdit(v)}>Edit</button>
                    {isAdmin&&<button className="danger-link" onClick={()=>onDelete(v)}>Delete</button>}
                  </div>
                </td>
              </tr>)}
            </tbody>
          </table>
          {!list.length&&<Empty/>}
        </div>
      </TablePanel>
    )}
  </div>;
}
function Stock({list,products,suppliers,isAdmin,onAdd}){return <><div className="stats-grid stock-stats"><StatCard label="Stock deliveries" value={list.length} sub="Recorded incoming deliveries" icon={Truck}/><StatCard label="Source suppliers" value={new Set(list.map(x=>x.supplier_id)).size} sub="Suppliers with stock history" icon={Store} tone="blue"/><StatCard label="Boxes received" value={list.reduce((n,x)=>n+Number(x.quantity),0)} sub="Lifetime receipts" icon={Boxes} tone="orange"/></div><TablePanel title="Incoming stock history" description="Every delivery is linked to its supplier and saleable product"><div className="table-scroll"><table><thead><tr><th>Received</th><th>Supplier</th><th>Product</th><th>Quantity</th><th>Unit cost</th><th>Purchase value</th></tr></thead><tbody>{list.map(s=><tr key={s.id}><td>{String(s.received_date).slice(0,10)}</td><td><b>{s.supplier_name}</b></td><td>{s.fruit_name} · {s.box_size}</td><td><b>{s.quantity}</b> boxes</td><td>{money(s.purchase_unit_cost)}</td><td className="price">{money(Number(s.quantity)*Number(s.purchase_unit_cost))}</td></tr>)}</tbody></table>{!list.length&&<Empty/>}</div></TablePanel></>}
function OrderTable({list,compact=false,onView}){return <div className="table-scroll"><table><thead><tr><th>Order</th><th>Vendor</th><th>Date</th><th>Total</th><th>Status</th>{!compact&&<th>Details</th>}</tr></thead><tbody>{list.map(o=><tr key={o.id}><td><b className="order-id">#BF-{String(o.id).padStart(4,'0')}</b></td><td>{o.vendor_name}</td><td>{String(o.order_date).slice(0,10)}</td><td className="price">{money(o.total_amount)}</td><td><span className={`badge ${o.status==='Completed'?'completed':o.status==='Cancelled'?'cancelled':o.status==='Pending'?'pending':'processing'}`}>{o.status}</span></td>{!compact&&<td><button className="row-link" onClick={()=>onView?.(o)}>View order ↗</button></td>}</tr>)}</tbody></table>{!list.length&&<Empty/>}</div>}
function Orders({list,vendors,products,isAdmin,onAdd,onStatus,onView}){const [status,setStatus]=useState('All');const filtered=list.filter(o=>status==='All'||o.status===status);return <><div className="filter-row"><div className="filter-label">ORDER STATUS</div><select value={status} onChange={e=>setStatus(e.target.value)}><option>All</option>{statuses.map(s=><option key={s}>{s}</option>)}</select><span className="results-count">{filtered.length} orders</span></div><div className="panel table-panel"><div className="panel-head"><div><h3>Order register</h3><p>Monitor order progress and fulfillment</p></div></div><OrderTable list={filtered} onView={onView}/></div><div className="panel status-guide"><b>Status workflow</b><span>Pending → Confirmed → Processing → Ready for Collection/Delivery → Completed</span><small>Completed orders reduce available stock. Cancelled orders do not.</small></div></>}
function Reports({reports}){const reportTable=(title,desc,headers,rows,keys,format=[]) => <div className="panel report-panel"><div className="panel-head"><div><h3>{title}</h3><p>{desc}</p></div></div><div className="table-scroll"><table><thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{(rows||[]).map((r,i)=><tr key={i}>{keys.map((k,j)=><td key={k} className={format.includes(k)?'price':''}>{format.includes(k)?money(r[k]):String(r[k]??'—')}</td>)}</tr>)}</tbody></table>{!rows?.length&&<Empty/>}</div></div>;
 return <><div className="report-grid"><StatCard label="Completed sales" value={money((reports.byFruit||[]).reduce((n,r)=>n+Number(r.sales||0),0))} sub="Completed order line items" icon={BarChart3}/><StatCard label="Fruit categories" value={(reports.byFruit||[]).length} sub="Fruit sales breakdown" icon={Apple} tone="blue"/><StatCard label="Vendors in report" value={(reports.byVendor||[]).length} sub="Sales by vendor" icon={Store} tone="orange"/></div><div className="reports-columns">{reportTable('Sales by fruit','Boxes sold and revenue by fruit',['Fruit','Boxes sold','Sales'],reports.byFruit,['fruit','boxes_sold','sales'],['sales'])}{reportTable('Sales by box size','Compare small, medium and large boxes',['Box size','Boxes sold','Sales'],reports.byBox,['box_size','boxes_sold','sales'],['sales'])}{reportTable('Sales by street vendor','Completed sales per vendor',['Vendor','Sales'],reports.byVendor,['vendor_name','sales'],['sales'])}{reportTable('Purchases by province','Incoming stock cost by supplier province',['Province','Boxes received','Purchase value'],reports.byProvince,['province','boxes_received','purchase_value'],['purchase_value'])}{reportTable('Pending orders','Orders that are not yet completed',['Order','Vendor','Status','Total'],reports.pending,['id','vendor_name','status','total_amount'],['total_amount'])}{reportTable('Completed orders','Fulfilled orders',['Order','Vendor','Status','Total'],reports.completed,['id','vendor_name','status','total_amount'],['total_amount'])}{reportTable('Sales by date','Daily completed order value',['Date','Sales'],reports.byDate,['sale_date','sales'],['sales'])}</div></>}
function Empty(){return <div className="empty-state"><span>⌕</span><b>No records to show</b><small>Try changing your search or add a record.</small></div>}
function Modal({modal,data,onClose,onSave,request,isAdmin}){
 const {type,item={}}=modal;const [form,setForm]=useState({...item});const [busy,setBusy]=useState(false);const [err,setErr]=useState('');
 const set=(k,v)=>setForm(p=>({...p,[k]:v}));
 const submit=async e=>{e.preventDefault();setBusy(true);setErr('');try{
  if(type==='order'){
   const items=[{product_id:Number(form.product_id),quantity:Number(form.quantity)}];
   const result=await request('/orders',{method:'POST',body:JSON.stringify({vendor_id:Number(form.vendor_id),items,notes:form.notes||''})});
   onClose();alert(`Order #${result.id} created. Total: ${money(result.total_amount)}`);window.location.reload();return;
  }
  let path='',method=item.id?'PUT':'POST',body={};
  if(type==='fruit'){path=`/fruits${item.id?`/${item.id}`:''}`;body={name:form.name,description:form.description||'',active:form.active!==false};}
  if(type==='product'){path=`/products${item.id?`/${item.id}`:''}`;body={fruit_id:Number(form.fruit_id),box_size_id:Number(form.box_size_id),selling_price:Number(form.selling_price),active:form.active!==false};}
  if(type==='supplier'){path=`/suppliers${item.id?`/${item.id}`:''}`;body={name:form.name,province:form.province,contact_person:form.contact_person,telephone:form.telephone,email:form.email||'',physical_address:form.physical_address};}
  if(type==='vendor'){
    path=`/vendors${item.id?`/${item.id}`:''}`;
    body={
      vendor_name:form.vendor_name,
      business_name:form.business_name,
      telephone:form.telephone,
      location_area:form.location_area,
      latitude:form.latitude!==''&&form.latitude!=null?Number(form.latitude):null,
      longitude:form.longitude!==''&&form.longitude!=null?Number(form.longitude):null,
      registration_date:form.registration_date||dateToday(),
      status:form.status||'Active'
    };
  }
  if(type==='stock'){path='/stock';body={supplier_id:Number(form.supplier_id),product_id:Number(form.product_id),quantity:Number(form.quantity),purchase_unit_cost:Number(form.purchase_unit_cost||0),received_date:form.received_date||dateToday(),notes:form.notes||''};}
  const result=await request(path,{method,body:JSON.stringify(body)});onClose();alert(result.message||'Saved.');window.location.reload();
 }catch(e){setErr(e.message);}finally{setBusy(false);}};
 if(type==='order-detail')return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal-card" onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><div><span className="eyebrow">ORDER DETAILS</span><h2>Order #BF-{String(item.id).padStart(4,'0')}</h2></div><button className="icon-button" onClick={onClose}><X/></button></div><div className="detail-summary"><b>{item.vendor_name}</b><span>{String(item.order_date).slice(0,10)} · {item.status}</span></div><div className="table-scroll"><table><thead><tr><th>Fruit</th><th>Box size</th><th>Qty</th><th>Subtotal</th></tr></thead><tbody>{(item.items||[]).map(x=><tr key={x.id}><td>{x.fruit_name}</td><td>{x.box_size}</td><td>{x.quantity}</td><td>{money(x.subtotal)}</td></tr>)}</tbody></table></div><div className="modal-total">Order total <b>{money(item.total_amount)}</b></div><div className="modal-actions"><button className="secondary-btn" onClick={onClose}>Close</button></div></div></div>;
 const title={fruit:item.id?'Edit fruit':'Add fruit',product:item.id?'Edit product':'Add product',supplier:item.id?'Edit supplier':'Add supplier',vendor:item.id?'Edit vendor':'Register street vendor',stock:'Receive incoming stock',order:'Create vendor order'}[type]||'Edit record';
 const field=(label,key,props={})=><label>{label}{props.select?<select value={form[key]??props.defaultValue??''} onChange={e=>set(key,e.target.value)} required={props.required!==false}><option value="">Choose…</option>{props.options.map(o=>typeof o==='string'?<option key={o}>{o}</option>:<option key={o.value} value={o.value}>{o.label}</option>)}</select>:<input type={props.inputType||'text'} value={form[key]??props.defaultValue??''} onChange={e=>set(key,e.target.value)} required={props.required!==false} min={props.min} step={props.step} placeholder={props.placeholder||''}/> }</label>;
 return <div className="modal-backdrop" onMouseDown={onClose}><form className="modal-card" onSubmit={submit} onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><div><span className="eyebrow">BATLOUNG FRUITS</span><h2>{title}</h2></div><button type="button" className="icon-button" onClick={onClose}><X/></button></div>{err&&<div className="alert error">{err}</div>}<div className="form-grid">
 {type==='fruit'&&<>{field('Fruit name','name',{select:true,options:fruitNames})}{field('Description','description',{required:false})}</>}
 {type==='product'&&<>{field('Fruit','fruit_id',{select:true,options:data.fruits.map(f=>({value:f.id,label:f.name}))})}{field('Box size','box_size_id',{select:true,options:data.boxSizes.map(b=>({value:b.id,label:b.name}))})}{field('Selling price (ZAR)','selling_price',{inputType:'number',min:'0',step:'0.01'})}</>}
 {type==='supplier'&&<>{field('Supplier name','name')}{field('Source province','province',{select:true,options:provinces})}{field('Contact person','contact_person')}{field('Telephone','telephone',{inputType:'tel'})}{field('Email address','email',{inputType:'email',required:false})}{field('Physical address','physical_address')}</>}
 {type==='vendor'&&<>{field('Vendor name','vendor_name')}{field('Business name','business_name')}{field('Telephone','telephone',{inputType:'tel'})}{field('Location / area in Maseru','location_area')}{field('Latitude (GPS)','latitude',{inputType:'number',step:'0.000001',required:false,placeholder:'e.g. -29.31680'})}{field('Longitude (GPS)','longitude',{inputType:'number',step:'0.000001',required:false,placeholder:'e.g. 27.48550'})}{field('Registration date','registration_date',{inputType:'date',defaultValue:dateToday()})}{field('Status','status',{select:true,options:['Active','Inactive'],defaultValue:'Active'})}<div style={{gridColumn:'1/-1'}}><LocationPickerModalTool latitude={form.latitude} longitude={form.longitude} locationArea={form.location_area} onChangeLat={lat=>set('latitude',lat)} onChangeLng={lng=>set('longitude',lng)} onChangeArea={area=>set('location_area',area)} depot={BATLOUNG_DEPOT}/></div></>}
 {type==='stock'&&<>{field('Supplier','supplier_id',{select:true,options:data.suppliers.map(s=>({value:s.id,label:`${s.name} · ${s.province}`}))})}{field('Product (fruit + box size)','product_id',{select:true,options:data.products.filter(p=>p.active).map(p=>({value:p.id,label:`${p.fruit_name} · ${p.box_size}`}))})}{field('Number of boxes received','quantity',{inputType:'number',min:'1',step:'1'})}{field('Purchase cost per box (ZAR)','purchase_unit_cost',{inputType:'number',min:'0',step:'0.01',defaultValue:'0'})}{field('Received date','received_date',{inputType:'date',defaultValue:dateToday()})}{field('Notes','notes',{required:false})}</>}
 {type==='order'&&<>{field('Registered street vendor','vendor_id',{select:true,options:data.vendors.filter(v=>v.status==='Active').map(v=>({value:v.id,label:`${v.vendor_name} · ${v.business_name}`}))})}{field('Product','product_id',{select:true,options:data.products.filter(p=>p.active&&Number(p.stock)>0).map(p=>({value:p.id,label:`${p.fruit_name} · ${p.box_size} (${p.stock} boxes in stock) — ${money(p.selling_price)}`}))})}{field('Quantity (boxes)','quantity',{inputType:'number',min:'1',step:'1'})}{field('Order notes','notes',{required:false})}<p className="form-note">The system calculates the total using the current product price and checks stock before saving.</p></>}
 </div><div className="modal-actions"><button type="button" className="secondary-btn" onClick={onClose}>Cancel</button><button className="primary-btn" disabled={busy}>{busy?'Saving…':'Save changes'}</button></div></form></div>;
}
export default App;
