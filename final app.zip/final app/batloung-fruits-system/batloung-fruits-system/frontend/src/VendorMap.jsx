import React, { useEffect, useRef, useState, useMemo } from 'react';
import L from 'leaflet';
import {
  MapPin,
  Navigation,
  Locate,
  Crosshair,
  Search,
  Store,
  Info,
  Phone,
  ArrowUpRight,
  Car,
  Bike,
  Footprints,
  Layers,
  Crown,
  Sparkles
} from 'lucide-react';

export const BATLOUNG_DEPOT = {
  name: 'Batloung Fruits Central Depot',
  address: 'Kingsway Road, Maseru Central, Maseru, Lesotho',
  lat: -29.31360,
  lng: 27.48440
};

export const MASERU_PRESETS = [
  { name: 'Maseru Central Market', area: 'Maseru Central Market', lat: -29.31680, lng: 27.48550 },
  { name: 'Pioneer Mall Area', area: 'Pioneer Mall, Kingsway Rd', lat: -29.31500, lng: 27.47600 },
  { name: 'Thetsane Industrial', area: 'Thetsane Industrial Area', lat: -29.35240, lng: 27.47210 },
  { name: 'Cathedral Area', area: 'Cathedral Area, Maseru', lat: -29.31120, lng: 27.49810 },
  { name: 'Pitso Ground', area: 'Pitso Ground, Maseru', lat: -29.31950, lng: 27.49050 },
  { name: 'Maseru Mall & Racecourse', area: 'Maseru Mall, Racecourse', lat: -29.33600, lng: 27.47600 },
  { name: 'Setsoto Stadium Area', area: 'Setsoto Stadium, Stadium Rd', lat: -29.32450, lng: 27.50850 },
  { name: 'Ha Mabote', area: 'Ha Mabote, Maseru', lat: -29.29420, lng: 27.53120 },
  { name: 'Qoaling', area: 'Qoaling, Maseru', lat: -29.34100, lng: 27.50200 },
  { name: 'Maseru Border Bridge', area: 'Maseru Bridge Border Post', lat: -29.30800, lng: 27.46400 },
  { name: 'Lithabaneng', area: 'Lithabaneng, Main South 1', lat: -29.34800, lng: 27.53100 }
];

// Distance in kilometers using Haversine formula
export function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return null;
  const nLat1 = Number(lat1), nLon1 = Number(lon1);
  const nLat2 = Number(lat2), nLon2 = Number(lon2);
  if (isNaN(nLat1) || isNaN(nLon1) || isNaN(nLat2) || isNaN(nLon2)) return null;
  const R = 6371; // Earth's radius in km
  const toRad = deg => (deg * Math.PI) / 180;
  const dLat = toRad(nLat2 - nLat1);
  const dLon = toRad(nLon2 - nLon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(nLat1)) * Math.cos(toRad(nLat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}

// Travel times estimate based on distance in km
export function calculateTravelTimes(distanceKm) {
  if (distanceKm == null || isNaN(distanceKm) || distanceKm <= 0) {
    return {
      car: '—',
      bike: '—',
      foot: '—',
      carMinutes: 0,
      bikeMinutes: 0,
      footMinutes: 0
    };
  }

  const formatDuration = (totalMinutes) => {
    const mins = Math.round(totalMinutes);
    if (mins < 1) return '< 1 min';
    if (mins < 60) return `${mins} min`;
    const hrs = Math.floor(mins / 60);
    const rem = mins % 60;
    return rem > 0 ? `${hrs}h ${rem}m` : `${hrs}h`;
  };

  // Speeds: Car ~35 km/h urban traffic, Bicycle ~15 km/h, Walking ~4.8 km/h
  const carMins = (distanceKm / 35) * 60;
  const bikeMins = (distanceKm / 15) * 60;
  const footMins = (distanceKm / 4.8) * 60;

  return {
    car: formatDuration(carMins),
    bike: formatDuration(bikeMins),
    foot: formatDuration(footMins),
    carMinutes: Math.round(carMins),
    bikeMinutes: Math.round(bikeMins),
    footMinutes: Math.round(footMins)
  };
}

// Reverse Geocoding & Destination Resolver
export async function resolveDestinationName(lat, lng) {
  if (lat == null || lng == null) return null;
  const nLat = Number(lat), nLng = Number(lng);
  if (isNaN(nLat) || isNaN(nLng)) return null;

  // 1. Attempt Nominatim Reverse Geocode with timeout
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${nLat}&lon=${nLng}&zoom=18&addressdetails=1`,
      {
        headers: { 'Accept-Language': 'en' },
        signal: controller.signal
      }
    );
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      const addr = data.address || {};

      const poi = addr.amenity || addr.shop || addr.commercial || addr.building || addr.office || addr.tourism;
      const road = addr.road || addr.pedestrian || addr.footway;
      const suburb = addr.suburb || addr.neighbourhood || addr.quarter || addr.village;
      const city = addr.city || addr.town || 'Maseru';

      const parts = [];
      if (poi) parts.push(poi);
      if (road && road !== poi) parts.push(road);
      if (suburb && suburb !== poi && suburb !== road) parts.push(suburb);

      if (parts.length === 0) {
        if (data.display_name) {
          parts.push(...data.display_name.split(',').slice(0, 2).map(s => s.trim()));
        } else {
          parts.push(city);
        }
      }

      const candidate = parts.slice(0, 2).join(', ');
      if (candidate && candidate.length > 2) {
        return candidate;
      }
    }
  } catch (e) {
    // Gracefully fall back to local spatial lookup
  }

  // 2. Spatial Landmark Matching (Find closest known Maseru landmark)
  let closestPreset = null;
  let minDistance = Infinity;
  for (const preset of MASERU_PRESETS) {
    const d = calculateDistanceKm(nLat, nLng, preset.lat, preset.lng);
    if (d != null && d < minDistance) {
      minDistance = d;
      closestPreset = preset;
    }
  }

  if (closestPreset) {
    if (minDistance <= 0.25) {
      return closestPreset.area;
    } else if (minDistance <= 2.5) {
      return `Near ${closestPreset.name} (~${minDistance} km)`;
    } else {
      return `${closestPreset.area} vicinity`;
    }
  }

  return 'Maseru Central, Lesotho';
}

// Map Tile Layers (Live Satellite Imagery vs Realistic Streets vs OSM)
export const TILE_PROVIDERS = {
  satellite: {
    id: 'satellite',
    name: 'Live Satellite',
    icon: '🛰️',
    description: 'High-res earth photography + road overlay',
    createLayers: () => [
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Imagery &copy; Esri, Maxar, Earthstar Geographics',
        maxZoom: 19
      }),
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Roads &copy; Esri',
        maxZoom: 19,
        opacity: 0.95
      }),
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Labels &copy; Esri',
        maxZoom: 19,
        opacity: 0.95
      })
    ]
  },
  streets: {
    id: 'streets',
    name: 'Realistic Streets',
    icon: '🏙️',
    description: 'Detailed GIS city street map',
    createLayers: () => [
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri &mdash; StreetMap',
        maxZoom: 19
      })
    ]
  },
  osm: {
    id: 'osm',
    name: 'OpenStreetMap',
    icon: '🗺️',
    description: 'Standard community street map',
    createLayers: () => [
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19
      })
    ]
  }
};

// Map Marker Icons
function createDepotIcon() {
  return L.divIcon({
    className: 'custom-map-icon',
    html: `
      <div class="depot-marker-wrapper">
        <div class="depot-pulse"></div>
        <div class="depot-pin">
          <span class="icon-inner">🍎</span>
        </div>
        <div class="marker-caption depot-caption">Batloung Depot (HQ)</div>
      </div>
    `,
    iconSize: [44, 44],
    iconAnchor: [22, 38],
    popupAnchor: [0, -40]
  });
}

function createVendorIcon(vendor, isSelected = false, isNearest = false) {
  const isActive = vendor.status === 'Active';
  const colorClass = isActive ? 'vendor-active' : 'vendor-inactive';
  const selectedClass = isSelected ? 'selected-pin' : '';
  const nearestClass = isNearest ? 'nearest-vendor-pin' : '';

  return L.divIcon({
    className: 'custom-map-icon',
    html: `
      <div class="vendor-marker-wrapper ${colorClass} ${selectedClass} ${nearestClass}">
        ${isNearest ? '<div class="nearest-crown-tag"><span class="crown-icon">👑</span> Nearest</div>' : ''}
        ${isNearest ? '<div class="nearest-pulse"></div>' : ''}
        <div class="vendor-pin">
          <span class="icon-inner">${isNearest ? '⭐' : isActive ? '🛒' : '⚪'}</span>
        </div>
        <div class="marker-caption">${vendor.vendor_name.split(' ')[0]}</div>
      </div>
    `,
    iconSize: [38, 38],
    iconAnchor: [19, 36],
    popupAnchor: [0, -38]
  });
}

function createPickerIcon(destinationName = '') {
  return L.divIcon({
    className: 'custom-map-icon',
    html: `
      <div class="picker-marker-wrapper">
        <div class="picker-pulse"></div>
        <div class="picker-pin">
          <span class="icon-inner">📍</span>
        </div>
        ${destinationName ? `<div class="marker-caption picker-caption">${destinationName.split(',')[0]}</div>` : ''}
      </div>
    `,
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -40]
  });
}

function createUserLocationIcon(destinationName = 'You are here') {
  return L.divIcon({
    className: 'custom-map-icon',
    html: `
      <div class="user-location-marker-wrapper">
        <div class="user-pulse"></div>
        <div class="user-pin">
          <span class="icon-inner">📍</span>
        </div>
        <div class="marker-caption user-caption">${destinationName.split(',')[0]}</div>
      </div>
    `,
    iconSize: [38, 38],
    iconAnchor: [19, 38],
    popupAnchor: [0, -40]
  });
}

// -------------------------------------------------------------
// Interactive Full-Page Map View for Street Vendors
// -------------------------------------------------------------
export function VendorMapView({ vendors = [], onEditVendor, depot = BATLOUNG_DEPOT }) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const activeTileLayersRef = useRef([]);
  const markersRef = useRef({});
  const polylineRef = useRef(null);
  const userMarkerRef = useRef(null);

  const [selectedVendorId, setSelectedVendorId] = useState(null);
  const [filterStatus, setFilterStatus] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [mapStyle, setMapStyle] = useState('satellite'); // Default to Live Satellite view
  const [travelMode, setTravelMode] = useState('car');   // 'car' | 'bike' | 'foot'
  const [sortBy, setSortBy] = useState('nearest');       // 'nearest' | 'furthest' | 'name'

  // Live user location ping state on the main map
  const [userLocation, setUserLocation] = useState(null);
  const [isPingingUser, setIsPingingUser] = useState(false);
  const [pingUserStatus, setPingUserStatus] = useState('');

  const validVendors = useMemo(() => {
    return vendors
      .filter(v => v.latitude != null && v.longitude != null && !isNaN(Number(v.latitude)) && !isNaN(Number(v.longitude)))
      .map(v => {
        const dist = v.distance_km ?? calculateDistanceKm(depot.lat, depot.lng, v.latitude, v.longitude);
        const travel = calculateTravelTimes(dist);
        return { ...v, calculatedDist: dist, travelTimes: travel };
      });
  }, [vendors, depot]);

  const unmappedVendors = useMemo(() => {
    return vendors.filter(v => v.latitude == null || v.longitude == null || isNaN(Number(v.latitude)) || isNaN(Number(v.longitude)));
  }, [vendors]);

  // Determine the nearest vendor to HQ
  const nearestVendor = useMemo(() => {
    if (!validVendors.length) return null;
    let minV = validVendors[0];
    for (let i = 1; i < validVendors.length; i++) {
      if (validVendors[i].calculatedDist != null && (minV.calculatedDist == null || validVendors[i].calculatedDist < minV.calculatedDist)) {
        minV = validVendors[i];
      }
    }
    return minV;
  }, [validVendors]);

  // Filter and sort vendors
  const displayedVendors = useMemo(() => {
    let list = validVendors.filter(v => {
      const matchStatus = filterStatus === 'All' || v.status === filterStatus;
      const q = searchTerm.toLowerCase();
      const matchSearch =
        !searchTerm ||
        v.vendor_name.toLowerCase().includes(q) ||
        v.business_name.toLowerCase().includes(q) ||
        (v.location_area && v.location_area.toLowerCase().includes(q));
      return matchStatus && matchSearch;
    });

    if (sortBy === 'nearest') {
      list.sort((a, b) => (a.calculatedDist ?? Infinity) - (b.calculatedDist ?? Infinity));
    } else if (sortBy === 'furthest') {
      list.sort((a, b) => (b.calculatedDist ?? -Infinity) - (a.calculatedDist ?? -Infinity));
    } else if (sortBy === 'name') {
      list.sort((a, b) => a.vendor_name.localeCompare(b.vendor_name));
    }

    return list;
  }, [validVendors, filterStatus, searchTerm, sortBy]);

  // Overall Statistics
  const stats = useMemo(() => {
    const distances = validVendors.map(v => v.calculatedDist).filter(d => d != null);
    if (!distances.length) return { avg: 0, min: 0, max: 0, total: validVendors.length };
    const min = Math.min(...distances);
    const max = Math.max(...distances);
    const avg = Math.round((distances.reduce((a, b) => a + b, 0) / distances.length) * 10) / 10;
    return { avg, min, max, total: validVendors.length };
  }, [validVendors]);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [depot.lat, depot.lng],
        zoom: 14,
        zoomControl: true
      });

      // Depot Marker
      const depotMarker = L.marker([depot.lat, depot.lng], { icon: createDepotIcon() }).addTo(map);
      depotMarker.bindPopup(`
        <div class="map-popup depot-popup">
          <div class="popup-eyebrow">HEADQUARTERS & CENTRAL DEPOT</div>
          <h4>${depot.name}</h4>
          <p class="popup-address">${depot.address}</p>
          <div class="popup-meta">
            <span>Coordinates: ${depot.lat}, ${depot.lng}</span>
          </div>
          <div class="popup-note">Distribution hub for all registered Maseru street vendors.</div>
        </div>
      `);

      // Coverage radius rings around depot (2km and 5km)
      L.circle([depot.lat, depot.lng], {
        radius: 2000,
        color: '#10b981',
        fillColor: '#34d399',
        fillOpacity: 0.06,
        weight: 1.5,
        dashArray: '4, 4'
      }).addTo(map);

      L.circle([depot.lat, depot.lng], {
        radius: 5000,
        color: '#0ea5e9',
        fillColor: '#38bdf8',
        fillOpacity: 0.04,
        weight: 1.2,
        dashArray: '6, 6'
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [depot]);

  // Update Tile Layers when mapStyle changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Remove existing tile layers
    activeTileLayersRef.current.forEach(layer => {
      if (map.hasLayer(layer)) map.removeLayer(layer);
    });
    activeTileLayersRef.current = [];

    // Add selected provider layers
    const provider = TILE_PROVIDERS[mapStyle] || TILE_PROVIDERS.satellite;
    const newLayers = provider.createLayers();
    newLayers.forEach(l => {
      l.addTo(map);
      activeTileLayersRef.current.push(l);
    });
  }, [mapStyle]);

  // Update Markers & Route Polyline
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear existing markers
    Object.values(markersRef.current).forEach(marker => marker.remove());
    markersRef.current = {};

    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }

    displayedVendors.forEach(vendor => {
      const isSelected = vendor.id === selectedVendorId;
      const isNearest = nearestVendor && vendor.id === nearestVendor.id;
      const dist = vendor.calculatedDist;
      const travel = vendor.travelTimes || calculateTravelTimes(dist);

      const marker = L.marker([Number(vendor.latitude), Number(vendor.longitude)], {
        icon: createVendorIcon(vendor, isSelected, isNearest)
      }).addTo(map);

      marker.bindPopup(`
        <div class="map-popup vendor-popup">
          <div class="popup-status-row">
            <span class="badge ${vendor.status === 'Active' ? 'completed' : 'cancelled'}">${vendor.status}</span>
            ${isNearest ? '<span class="nearest-mini-badge">👑 NEAREST TO HQ</span>' : ''}
            <span class="popup-distance">📏 <b>${dist != null ? `${dist} km` : '—'}</b></span>
          </div>
          <h4>${vendor.vendor_name}</h4>
          <p class="popup-business"><b>${vendor.business_name}</b></p>
          <p class="popup-area">📍 Destination: <b>${vendor.location_area || 'Maseru'}</b></p>
          <p class="popup-phone">📞 ${vendor.telephone}</p>

          <div class="popup-travel-section">
            <div class="travel-section-title">⏱️ ESTIMATED TRAVEL TIMES TO HQ:</div>
            <div class="popup-travel-grid">
              <div class="travel-pill ${travelMode === 'car' ? 'active-mode' : ''}">
                <span class="mode-icon">🚗</span>
                <span class="mode-label">Car</span>
                <strong>${travel.car}</strong>
              </div>
              <div class="travel-pill ${travelMode === 'bike' ? 'active-mode' : ''}">
                <span class="mode-icon">🚲</span>
                <span class="mode-label">Bike</span>
                <strong>${travel.bike}</strong>
              </div>
              <div class="travel-pill ${travelMode === 'foot' ? 'active-mode' : ''}">
                <span class="mode-icon">🚶</span>
                <span class="mode-label">Foot</span>
                <strong>${travel.foot}</strong>
              </div>
            </div>
          </div>

          <div class="popup-actions">
            <button class="popup-btn edit-btn" id="edit-vendor-${vendor.id}">Edit Vendor Details</button>
          </div>
        </div>
      `);

      marker.on('click', () => {
        setSelectedVendorId(vendor.id);
      });

      marker.on('popupopen', () => {
        const btn = document.getElementById(`edit-vendor-${vendor.id}`);
        if (btn && onEditVendor) {
          btn.onclick = () => onEditVendor(vendor);
        }
      });

      markersRef.current[vendor.id] = marker;
    });

    // Draw route line to selected vendor if one is selected
    if (selectedVendorId) {
      const sel = displayedVendors.find(v => v.id === selectedVendorId);
      if (sel) {
        const dist = sel.calculatedDist;
        const travel = sel.travelTimes || calculateTravelTimes(dist);
        const latlngs = [
          [depot.lat, depot.lng],
          [Number(sel.latitude), Number(sel.longitude)]
        ];

        const line = L.polyline(latlngs, {
          color: '#10b981',
          weight: 4,
          dashArray: '8, 8',
          opacity: 0.95
        }).addTo(map);

        const activeModeTime = travelMode === 'car' ? `🚗 ${travel.car}` : travelMode === 'bike' ? `🚲 ${travel.bike}` : `🚶 ${travel.foot}`;

        line.bindTooltip(`
          <div class="route-tooltip-inner">
            <strong>${dist} km</strong> to ${sel.vendor_name}
            <div class="tooltip-travel-times">
              <span>🚗 ${travel.car}</span> · <span>🚲 ${travel.bike}</span> · <span>🚶 ${travel.foot}</span>
            </div>
          </div>
        `, {
          permanent: true,
          direction: 'center',
          className: 'map-distance-tooltip'
        });

        polylineRef.current = line;
      }
    }
  }, [displayedVendors, selectedVendorId, nearestVendor, depot, onEditVendor, travelMode]);

  // Select and focus on a vendor
  const selectVendor = (vendor) => {
    setSelectedVendorId(vendor.id);
    const map = mapInstanceRef.current;
    if (map && vendor.latitude && vendor.longitude) {
      map.setView([Number(vendor.latitude), Number(vendor.longitude)], 15, { animate: true });
      const marker = markersRef.current[vendor.id];
      if (marker) marker.openPopup();
    }
  };

  const focusDepot = () => {
    setSelectedVendorId(null);
    const map = mapInstanceRef.current;
    if (map) {
      map.setView([depot.lat, depot.lng], 14, { animate: true });
    }
  };

  const fitAll = () => {
    const map = mapInstanceRef.current;
    if (!map) return;
    const pts = [[depot.lat, depot.lng], ...displayedVendors.map(v => [Number(v.latitude), Number(v.longitude)])];
    if (pts.length > 1) {
      map.fitBounds(pts, { padding: [45, 45] });
    } else {
      map.setView([depot.lat, depot.lng], 14);
    }
  };

  // Live GPS pinging on the main map
  const handlePingMainMap = () => {
    if (!navigator.geolocation) {
      setPingUserStatus('Geolocation is not supported by your browser.');
      return;
    }

    setIsPingingUser(true);
    setPingUserStatus('Acquiring live GPS position...');

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = Math.round(pos.coords.latitude * 100000) / 100000;
        const lng = Math.round(pos.coords.longitude * 100000) / 100000;
        const distToDepot = calculateDistanceKm(depot.lat, depot.lng, lat, lng);
        const depotTravel = calculateTravelTimes(distToDepot);

        const destName = await resolveDestinationName(lat, lng) || 'Current Location';

        setUserLocation({ lat, lng, destinationName: destName, distToDepot, travelTimes: depotTravel });
        setIsPingingUser(false);

        // Find nearest vendor to this pinged position
        let closestVendor = null;
        let minD = Infinity;
        validVendors.forEach(v => {
          const d = calculateDistanceKm(lat, lng, v.latitude, v.longitude);
          if (d != null && d < minD) {
            minD = d;
            closestVendor = { ...v, distToUser: d, userTravel: calculateTravelTimes(d) };
          }
        });

        const statusMsg = closestVendor
          ? `📍 Live GPS Pinged at "${destName}" (${lat}, ${lng}) — ${distToDepot} km from Depot (🚗 ~${depotTravel.car} · 🚲 ~${depotTravel.bike} · 🚶 ~${depotTravel.foot}). Closest vendor to you: ${closestVendor.vendor_name} (${closestVendor.distToUser} km away, 🚶 ~${closestVendor.userTravel.foot}).`
          : `📍 Live GPS Pinged at "${destName}" (${lat}, ${lng}) — ${distToDepot} km from Depot (🚗 ~${depotTravel.car} · 🚲 ~${depotTravel.bike} · 🚶 ~${depotTravel.foot}).`;

        setPingUserStatus(statusMsg);

        const map = mapInstanceRef.current;
        if (map) {
          if (userMarkerRef.current) userMarkerRef.current.remove();
          const marker = L.marker([lat, lng], { icon: createUserLocationIcon(destName) }).addTo(map);
          marker.bindPopup(`
            <div class="map-popup user-location-popup">
              <div class="popup-eyebrow">LIVE USER GPS LOCATION</div>
              <h4>📍 ${destName}</h4>
              <p class="popup-address">Coordinates: ${lat}, ${lng}</p>
              <div class="popup-distance">📏 <b>${distToDepot} km</b> to Batloung Fruits Depot</div>
              <div class="popup-travel-section">
                <div class="travel-section-title">⏱️ TIME TO CENTRAL DEPOT:</div>
                <div class="popup-travel-grid">
                  <div class="travel-pill">🚗 ${depotTravel.car}</div>
                  <div class="travel-pill">🚲 ${depotTravel.bike}</div>
                  <div class="travel-pill">🚶 ${depotTravel.foot}</div>
                </div>
              </div>
            </div>
          `).openPopup();
          userMarkerRef.current = marker;
          map.setView([lat, lng], 15, { animate: true });
        }
      },
      (err) => {
        setIsPingingUser(false);
        setPingUserStatus(`Could not acquire location: ${err.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  return (
    <div className="vendor-map-page">
      {/* Nearest Vendor Spotlight Banner */}
      {nearestVendor && (
        <div className="nearest-vendor-banner">
          <div className="nearest-banner-left">
            <div className="nearest-crown-icon">
              <Crown size={22} className="crown-svg" />
            </div>
            <div>
              <div className="nearest-badge-tag">
                <span>👑 NEAREST VENDOR TO HQ</span>
                <span className="dist-chip">{nearestVendor.calculatedDist} km from Depot</span>
              </div>
              <h3 className="nearest-vendor-name">
                {nearestVendor.vendor_name} <span className="nearest-biz">({nearestVendor.business_name})</span>
              </h3>
              <p className="nearest-dest-area">
                📍 Destination: <b>{nearestVendor.location_area || 'Maseru Central'}</b>
              </p>
            </div>
          </div>

          <div className="nearest-banner-middle">
            <div className="nearest-travel-chips">
              <span className={`travel-chip ${travelMode === 'car' ? 'active' : ''}`} title="Driving by car">
                <Car size={13} /> <b>{nearestVendor.travelTimes?.car}</b>
              </span>
              <span className={`travel-chip ${travelMode === 'bike' ? 'active' : ''}`} title="Cycling by bike">
                <Bike size={13} /> <b>{nearestVendor.travelTimes?.bike}</b>
              </span>
              <span className={`travel-chip ${travelMode === 'foot' ? 'active' : ''}`} title="Walking on foot">
                <Footprints size={13} /> <b>{nearestVendor.travelTimes?.foot}</b>
              </span>
            </div>
          </div>

          <div className="nearest-banner-actions">
            <button
              className="nearest-locate-btn"
              onClick={() => selectVendor(nearestVendor)}
              title="Locate nearest vendor on map"
            >
              <Crosshair size={15} /> Show Route & Pin
            </button>
          </div>
        </div>
      )}

      {/* Top Map Stats & Quick Controls Strip */}
      <div className="map-stats-strip">
        <div className="stat-pill">
          <Store size={15} />
          <span><b>{validVendors.length}</b> Mapped Vendors</span>
        </div>
        <div className="stat-pill">
          <Navigation size={15} />
          <span>Avg Distance: <b>{stats.avg} km</b></span>
        </div>
        {nearestVendor && (
          <button
            className="stat-pill nearest-interactive"
            onClick={() => selectVendor(nearestVendor)}
            title="Click to zoom to nearest vendor"
          >
            <Crown size={14} className="crown-mini" />
            <span>Nearest: <b>{nearestVendor.vendor_name} ({stats.min} km)</b></span>
          </button>
        )}
        <div className="stat-pill">
          <span>Furthest: <b>{stats.max} km</b></span>
        </div>

        {unmappedVendors.length > 0 && (
          <div className="stat-pill warn">
            <Info size={15} />
            <span><b>{unmappedVendors.length}</b> vendor(s) need coordinates</span>
          </div>
        )}

        <div className="map-quick-buttons">
          <button
            className="small-action-btn ping-location-action"
            onClick={handlePingMainMap}
            disabled={isPingingUser}
            title="Ping my live GPS position"
          >
            <Locate size={13} />
            {isPingingUser ? 'Pinging GPS…' : 'Ping My Location'}
          </button>
          <button className="small-action-btn" onClick={focusDepot} title="Focus Batloung Central Depot">
            🏢 Batloung Depot
          </button>
          <button className="small-action-btn" onClick={fitAll} title="Fit all vendors on map">
            ⛶ Fit All
          </button>
        </div>
      </div>

      {pingUserStatus && (
        <div className="ping-status-note">
          <Info size={14} />
          <span>{pingUserStatus}</span>
        </div>
      )}

      {/* Main Map + Side Panel Layout */}
      <div className="map-view-layout">
        {/* Leaflet Map Canvas */}
        <div className="map-canvas-wrap">
          {/* Layer Switcher Controls (Floating Top-Right) */}
          <div className="map-layer-switcher">
            <div className="layer-switcher-label">
              <Layers size={13} /> View Mode:
            </div>
            <div className="layer-button-group">
              {Object.values(TILE_PROVIDERS).map(provider => (
                <button
                  key={provider.id}
                  type="button"
                  className={`layer-toggle-btn ${mapStyle === provider.id ? 'active' : ''}`}
                  onClick={() => setMapStyle(provider.id)}
                  title={provider.description}
                >
                  <span>{provider.icon}</span> {provider.name}
                </button>
              ))}
            </div>
          </div>

          <div ref={mapContainerRef} className="map-element" style={{ width: '100%', height: '580px' }} />

          <div className="map-legend">
            <div><span className="legend-dot depot"></span> Batloung Depot (HQ)</div>
            <div><span className="legend-dot nearest"></span> 👑 Nearest Vendor</div>
            <div><span className="legend-dot active"></span> Active Vendor</div>
            <div><span className="legend-dot inactive"></span> Inactive Vendor</div>
            <div><span className="legend-line"></span> 2km / 5km Service Radius</div>
          </div>
        </div>

        {/* Vendors Side Panel */}
        <div className="map-side-panel">
          <div className="side-panel-header">
            <div className="side-title-row">
              <h4>Vendors & Travel Times</h4>
              <span className="vendor-counter">{displayedVendors.length} active</span>
            </div>

            {/* Travel Mode Selector */}
            <div className="travel-mode-bar">
              <span className="mode-bar-label">Travel Time:</span>
              <div className="travel-mode-toggles">
                <button
                  type="button"
                  className={`mode-btn ${travelMode === 'car' ? 'active' : ''}`}
                  onClick={() => setTravelMode('car')}
                  title="Estimate drive time by car (~35 km/h)"
                >
                  <Car size={13} /> Car
                </button>
                <button
                  type="button"
                  className={`mode-btn ${travelMode === 'bike' ? 'active' : ''}`}
                  onClick={() => setTravelMode('bike')}
                  title="Estimate cycling time by bicycle (~15 km/h)"
                >
                  <Bike size={13} /> Bike
                </button>
                <button
                  type="button"
                  className={`mode-btn ${travelMode === 'foot' ? 'active' : ''}`}
                  onClick={() => setTravelMode('foot')}
                  title="Estimate walking time on foot (~4.8 km/h)"
                >
                  <Footprints size={13} /> On Foot
                </button>
              </div>
            </div>

            <div className="side-filter-row">
              <div className="side-search">
                <Search size={14} />
                <input
                  type="text"
                  placeholder="Search vendor or destination..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
              <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                <option value="All">All Statuses</option>
                <option value="Active">Active only</option>
                <option value="Inactive">Inactive only</option>
              </select>
            </div>

            <div className="side-sort-row">
              <span className="sort-label">Sort:</span>
              <button
                type="button"
                className={`sort-pill ${sortBy === 'nearest' ? 'active' : ''}`}
                onClick={() => setSortBy('nearest')}
              >
                Nearest First
              </button>
              <button
                type="button"
                className={`sort-pill ${sortBy === 'furthest' ? 'active' : ''}`}
                onClick={() => setSortBy('furthest')}
              >
                Furthest First
              </button>
              <button
                type="button"
                className={`sort-pill ${sortBy === 'name' ? 'active' : ''}`}
                onClick={() => setSortBy('name')}
              >
                Name A-Z
              </button>
            </div>
          </div>

          <div className="vendor-distance-list">
            {displayedVendors.map(vendor => {
              const isSelected = vendor.id === selectedVendorId;
              const isNearest = nearestVendor && vendor.id === nearestVendor.id;
              const dist = vendor.calculatedDist;
              const travel = vendor.travelTimes || calculateTravelTimes(dist);
              const selectedTime = travelMode === 'car' ? travel.car : travelMode === 'bike' ? travel.bike : travel.foot;

              return (
                <div
                  key={vendor.id}
                  className={`vendor-side-card ${isSelected ? 'active-card' : ''} ${isNearest ? 'nearest-card' : ''}`}
                  onClick={() => selectVendor(vendor)}
                >
                  <div className="side-card-top">
                    <div>
                      <div className="vendor-name-row">
                        <strong className="vendor-name-label">{vendor.vendor_name}</strong>
                        {isNearest && <span className="crown-badge">👑 Nearest</span>}
                      </div>
                      <span className="business-sub">{vendor.business_name}</span>
                    </div>

                    <div className="distance-travel-badges">
                      <span className="distance-badge-pill">
                        {dist != null ? `${dist} km` : '—'}
                      </span>
                      <span className="travel-badge-pill" title={`Time by ${travelMode}`}>
                        {travelMode === 'car' ? '🚗' : travelMode === 'bike' ? '🚲' : '🚶'} {selectedTime}
                      </span>
                    </div>
                  </div>

                  {/* Travel times mini row */}
                  <div className="side-card-travel-preview">
                    <span title="Car drive time">🚗 {travel.car}</span>
                    <span className="dot-sep">·</span>
                    <span title="Bicycle cycle time">🚲 {travel.bike}</span>
                    <span className="dot-sep">·</span>
                    <span title="Walking time on foot">🚶 {travel.foot}</span>
                  </div>

                  <div className="side-card-bottom">
                    <span className="area-text">📍 Destination: {vendor.location_area || 'Maseru'}</span>
                    <button
                      className="edit-mini-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditVendor?.(vendor);
                      }}
                      title="Edit Vendor"
                    >
                      Edit ↗
                    </button>
                  </div>
                </div>
              );
            })}

            {!displayedVendors.length && (
              <div className="empty-side-list">
                <Info size={20} />
                <span>No matching vendors with coordinates.</span>
              </div>
            )}

            {unmappedVendors.length > 0 && (
              <div className="unmapped-section">
                <div className="unmapped-title">Vendors missing coordinates:</div>
                {unmappedVendors.map(uv => (
                  <div key={uv.id} className="unmapped-row">
                    <span>{uv.vendor_name} ({uv.location_area || 'No area'})</span>
                    <button className="row-link" onClick={() => onEditVendor?.(uv)}>Set location</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// Interactive Location Picker & Ping Tool (Used in Vendor Modal)
// -------------------------------------------------------------
export function LocationPickerModalTool({
  latitude,
  longitude,
  locationArea,
  onChangeLat,
  onChangeLng,
  onChangeArea,
  depot = BATLOUNG_DEPOT
}) {
  const pickerMapRef = useRef(null);
  const pickerInstanceRef = useRef(null);
  const pickerTileLayersRef = useRef([]);
  const pickerMarkerRef = useRef(null);

  const [showMap, setShowMap] = useState(true);
  const [mapStyle, setMapStyle] = useState('satellite'); // Default to Live Satellite view
  const [pingStatus, setPingStatus] = useState('');
  const [isPinging, setIsPinging] = useState(false);
  const [isResolvingArea, setIsResolvingArea] = useState(false);

  const currentLat = latitude ? Number(latitude) : null;
  const currentLng = longitude ? Number(longitude) : null;
  const hasCoords = currentLat != null && currentLng != null && !isNaN(currentLat) && !isNaN(currentLng);

  const distance = useMemo(() => {
    if (!hasCoords) return null;
    return calculateDistanceKm(depot.lat, depot.lng, currentLat, currentLng);
  }, [currentLat, currentLng, depot]);

  const travelTimes = useMemo(() => {
    return calculateTravelTimes(distance);
  }, [distance]);

  // Update destination area name from coordinates (Reverse Geocode)
  const updateDestinationFromCoords = async (lat, lng) => {
    setIsResolvingArea(true);
    const destName = await resolveDestinationName(lat, lng);
    setIsResolvingArea(false);
    if (destName) {
      onChangeArea?.(destName);
    }
    return destName;
  };

  // Initialize or update picker map
  useEffect(() => {
    if (!showMap || !pickerMapRef.current) return;

    const startLat = hasCoords ? currentLat : depot.lat;
    const startLng = hasCoords ? currentLng : depot.lng;

    if (!pickerInstanceRef.current) {
      const map = L.map(pickerMapRef.current, {
        center: [startLat, startLng],
        zoom: hasCoords ? 15 : 13,
        zoomControl: true
      });

      // Depot reference marker
      L.marker([depot.lat, depot.lng], { icon: createDepotIcon() })
        .addTo(map)
        .bindPopup('<b>Batloung Fruits Central Depot (HQ)</b>');

      // Click on map to place pin & auto-detect destination
      map.on('click', async (e) => {
        const { lat, lng } = e.latlng;
        const roundedLat = Math.round(lat * 100000) / 100000;
        const roundedLng = Math.round(lng * 100000) / 100000;
        onChangeLat(roundedLat);
        onChangeLng(roundedLng);

        const destName = await updateDestinationFromCoords(roundedLat, roundedLng);
        const dist = calculateDistanceKm(depot.lat, depot.lng, roundedLat, roundedLng);
        const times = calculateTravelTimes(dist);
        setPingStatus(`📍 Pinned at "${destName || 'Selected Location'}" (${roundedLat}, ${roundedLng}) — ${dist} km from Depot (🚗 ~${times.car} · 🚲 ~${times.bike} · 🚶 ~${times.foot}).`);
      });

      pickerInstanceRef.current = map;
    } else {
      pickerInstanceRef.current.invalidateSize();
    }

    const map = pickerInstanceRef.current;

    // Update or create draggable pin
    if (hasCoords) {
      if (pickerMarkerRef.current) {
        pickerMarkerRef.current.setLatLng([currentLat, currentLng]);
      } else {
        const marker = L.marker([currentLat, currentLng], {
          icon: createPickerIcon(locationArea),
          draggable: true
        }).addTo(map);

        marker.on('dragend', async (e) => {
          const pt = e.target.getLatLng();
          const rLat = Math.round(pt.lat * 100000) / 100000;
          const rLng = Math.round(pt.lng * 100000) / 100000;
          onChangeLat(rLat);
          onChangeLng(rLng);

          const destName = await updateDestinationFromCoords(rLat, rLng);
          const dist = calculateDistanceKm(depot.lat, depot.lng, rLat, rLng);
          const times = calculateTravelTimes(dist);
          setPingStatus(`📍 Dragged pin to "${destName || 'Selected Location'}" (${rLat}, ${rLng}) — ${dist} km from Depot.`);
        });

        pickerMarkerRef.current = marker;
      }
    } else {
      if (pickerMarkerRef.current) {
        pickerMarkerRef.current.remove();
        pickerMarkerRef.current = null;
      }
    }
  }, [showMap, hasCoords, currentLat, currentLng, depot, onChangeLat, onChangeLng, locationArea]);

  // Update Tile Layers for Picker Map
  useEffect(() => {
    const map = pickerInstanceRef.current;
    if (!map) return;

    pickerTileLayersRef.current.forEach(layer => {
      if (map.hasLayer(layer)) map.removeLayer(layer);
    });
    pickerTileLayersRef.current = [];

    const provider = TILE_PROVIDERS[mapStyle] || TILE_PROVIDERS.satellite;
    const newLayers = provider.createLayers();
    newLayers.forEach(l => {
      l.addTo(map);
      pickerTileLayersRef.current.push(l);
    });
  }, [mapStyle, showMap]);

  // Clean up picker map when component unmounts
  useEffect(() => {
    return () => {
      if (pickerInstanceRef.current) {
        pickerInstanceRef.current.remove();
        pickerInstanceRef.current = null;
      }
    };
  }, []);

  // Ping current location via browser Geolocation API & Auto-add destination name
  const handlePingLocation = () => {
    if (!navigator.geolocation) {
      setPingStatus('Geolocation is not supported by your browser.');
      return;
    }

    setIsPinging(true);
    setPingStatus('Requesting GPS coordinates from device...');

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const lat = Math.round(position.coords.latitude * 100000) / 100000;
        const lng = Math.round(position.coords.longitude * 100000) / 100000;

        onChangeLat(lat);
        onChangeLng(lng);

        setPingStatus(`Resolving destination name for (${lat}, ${lng})...`);
        const destName = await updateDestinationFromCoords(lat, lng);

        setIsPinging(false);
        const dist = calculateDistanceKm(depot.lat, depot.lng, lat, lng);
        const times = calculateTravelTimes(dist);

        const resolvedText = destName ? `"${destName}"` : 'Current Destination';
        setPingStatus(`✅ Location pinged! Destination set to ${resolvedText} (${lat}, ${lng}) — ${dist} km from Batloung HQ. 🚗 ~${times.car} · 🚲 ~${times.bike} · 🚶 ~${times.foot}`);

        if (pickerInstanceRef.current) {
          pickerInstanceRef.current.setView([lat, lng], 15, { animate: true });
        }
      },
      (err) => {
        setIsPinging(false);
        setPingStatus(`Could not get GPS location: ${err.message}. You can still click on the map to pin destination.`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const applyPreset = (preset) => {
    onChangeLat(preset.lat);
    onChangeLng(preset.lng);
    onChangeArea?.(preset.area);
    const dist = calculateDistanceKm(depot.lat, depot.lng, preset.lat, preset.lng);
    const times = calculateTravelTimes(dist);
    setPingStatus(`Selected "${preset.name}" — ${dist} km from Batloung HQ (🚗 ~${times.car} · 🚲 ~${times.bike} · 🚶 ~${times.foot}).`);

    if (pickerInstanceRef.current) {
      pickerInstanceRef.current.setView([preset.lat, preset.lng], 15, { animate: true });
    }
  };

  return (
    <div className="location-picker-container">
      <div className="location-picker-head">
        <div>
          <span className="location-section-title">📍 VENDOR LOCATION & GPS DESTINATION</span>
          <p className="location-subtext">
            Pin the vendor location on the live satellite map to auto-fill destination names and calculate travel times.
          </p>
        </div>
        <div className="location-ping-actions">
          <button
            type="button"
            className="ping-btn"
            onClick={handlePingLocation}
            disabled={isPinging || isResolvingArea}
          >
            <Locate size={15} />
            {isPinging ? 'Pinging GPS…' : isResolvingArea ? 'Resolving Destination…' : 'Ping My Location'}
          </button>
          <button
            type="button"
            className="toggle-map-btn"
            onClick={() => setShowMap(!showMap)}
          >
            {showMap ? 'Hide Map' : 'Show Map'}
          </button>
        </div>
      </div>

      {pingStatus && (
        <div className="ping-status-note">
          <Info size={14} />
          <span>{pingStatus}</span>
        </div>
      )}

      {/* Preset Destination Chips */}
      <div className="presets-bar">
        <span className="presets-label">Popular Maseru Destinations:</span>
        <div className="preset-chips">
          {MASERU_PRESETS.map((p) => (
            <button
              key={p.name}
              type="button"
              className="preset-chip"
              onClick={() => applyPreset(p)}
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Mini Leaflet Picker Map */}
      {showMap && (
        <div className="picker-map-wrap">
          {/* Mini map layer toggle */}
          <div className="picker-layer-bar">
            <span className="picker-layer-label">Layer:</span>
            {Object.values(TILE_PROVIDERS).map(provider => (
              <button
                key={provider.id}
                type="button"
                className={`picker-layer-btn ${mapStyle === provider.id ? 'active' : ''}`}
                onClick={() => setMapStyle(provider.id)}
              >
                {provider.icon} {provider.name}
              </button>
            ))}
          </div>

          <div ref={pickerMapRef} style={{ width: '100%', height: '240px', borderRadius: '0 0 8px 8px' }} />
          <div className="picker-hint">
            💡 Click anywhere or drag the pin to set vendor location. The destination name will auto-populate!
          </div>
        </div>
      )}

      {/* Distance & Travel Times readout card */}
      <div className="distance-readout-card">
        <div className="distance-icon-col">
          <Navigation size={22} className="nav-arrow" />
        </div>
        <div className="distance-text-col" style={{ width: '100%' }}>
          <div className="distance-label">DISTANCE & TIME TO BATLOUNG CENTRAL DEPOT</div>
          {hasCoords ? (
            <div className="distance-value-block">
              <div className="distance-primary-row">
                <strong>{distance} km</strong>
                <span className="destination-name-badge">
                  📍 {locationArea || 'Destination Detected'}
                </span>
                <span className="coords-sub">({currentLat}, {currentLng})</span>
              </div>

              {/* Travel Time Estimates Breakdown */}
              <div className="picker-travel-times-row">
                <div className="picker-travel-pill">
                  <span className="mode-icon">🚗</span>
                  <span className="mode-title">By Car:</span>
                  <b>{travelTimes.car}</b>
                </div>
                <div className="picker-travel-pill">
                  <span className="mode-icon">🚲</span>
                  <span className="mode-title">By Bicycle:</span>
                  <b>{travelTimes.bike}</b>
                </div>
                <div className="picker-travel-pill">
                  <span className="mode-icon">🚶</span>
                  <span className="mode-title">On Foot:</span>
                  <b>{travelTimes.foot}</b>
                </div>
              </div>
            </div>
          ) : (
            <div className="distance-empty">
              Pin a location on the map or click "Ping My Location" to calculate distance and travel time.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
