@echo off
title Launch Batloung Fruits System
echo ==============================================
echo   Starting Batloung Fruits System Services
echo ==============================================

start "Batloung API (Port 5000)" cmd /k "cd /d %~dp0backend && node server.js"
start "Batloung Frontend (Port 5173)" cmd /k "cd /d %~dp0frontend && npm run dev"

echo.
echo Both servers have been launched in dedicated terminal windows!
echo - API Backend: http://localhost:5000
echo - Frontend:    http://localhost:5173
echo.
pause
